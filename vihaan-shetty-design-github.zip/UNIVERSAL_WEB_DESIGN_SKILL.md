# Vihaan Shetty Design Intelligence — Portable Edition

**Status:** Personal beta. Skill-assisted development smoke-tested; non-isolated, non-blinded, and not release-benchmark validated. Do not describe it as release-benchmark validated.

## Use with any model

Attach this file to a project, paste it into the model's persistent project instructions, or provide it before a substantial web-design task. Tell the model to follow the authority order and load only the sections relevant to the task. For Codex, use the native `SKILL.md` package in this repository instead.

This portable edition contains the complete human/model-readable instruction set and supporting reference material. It deliberately excludes private research, benchmark fixtures, runner archives, and evaluation harnesses.

---

## Source: `SKILL.md`

# Vihaan-Shetty-DESIGN

This is a **personal beta — skill-assisted development smoke-tested, non-isolated, non-blinded, and not release-benchmark validated**. Do not publish or describe it as release-benchmark validated.

## Authority

Resolve every decision in this order:

1. **Project truth** — user scope, content, audience, brand, behavior, repository, constraints, and real data.
2. **Platform foundations** — semantics, established controls, accessibility, responsive behavior, performance, browser/input realities, privacy, and graceful degradation.
3. **Creative corpus** — validated causal design intelligence. It expands vocabulary but never overrides the first two authorities.

Never invent product proof, data, functionality, reference mechanics, or authorization. Do not copy reference branding, text, assets, distinctive compositions, or substantial code.

## Classify the task

Before loading supporting material, classify the request:

- **Small fix:** bounded spacing, contrast, overlap, responsive, state, or animation repair. Make the narrow change; ask no design interview.
- **Existing-product change:** inspect repository and rendered product before questions or direction. Read existing-project.md. For a substantial change also read frontend-and-regression.md.
- **Greenfield or major new page:** establish purpose, content, task spine, constraints, and material unknowns. Read greenfield.md.
- **Major direction/redesign:** read interview-and-direction.md, synthesis-and-expressiveness.md, and originality-and-anti-generic.md.
- **Material motion, Canvas, or WebGL:** additionally read motion-selection-and-engineering.md.
- **Substantial implementation:** read responsive-accessibility-performance.md.
- **Rendered verification:** read browser-qa.md.
- **QA, critique, or audit only:** inspect the supplied implementation and load only the relevant delivery reference; do not invent a redesign mandate.

Do not load all references. Load whole focused files only when their trigger applies.

## Operating loop

Use the smallest applicable portion of:

`UNDERSTAND → RESOLVE MATERIAL UNCERTAINTY → OBSERVE → MODEL RELATIONSHIPS → SYNTHESIZE → COMMIT → IMPLEMENT → RENDER → INSPECT → CRITIQUE → REFINE → VERIFY`

### 1. Understand before styling

Identify the primary user outcome, audience, trust/error stakes, content structure, brand equities, repeat-use pattern, supported devices, and delivery constraints. In an existing project, inspect routes, components, tokens, assets, dependencies, states, tests, and project instructions. Run the current interface when possible.

### 2. Ask only consequential questions

Ask zero questions for small fixes, fully specified tasks, or safe “choose for me” requests. Otherwise, for substantial greenfield work or a major redesign, ask two to four project-specific comparative questions only if answers would materially change the direction. Never ask what the brief, repository, conversation, or rendered product already answers. Stop early when remaining uncertainty is low. Reopen questions only for a newly discovered consequential conflict.

### 3. Commit to a direction

For major work, create a direction contract using direction-contract.md. Establish task spine, experience thesis, concept seed, composition, typography, content/imagery treatment, interaction and motion roles, expressive profile, responsive transformations, accessibility invariants, performance limits, fallbacks, and explicit “not this” boundaries.

If corpus knowledge is used, read the compact corpus index, select at most three relevant validated cards, and load at most one vocabulary module. Record the decision using project-selection.md and source-ledger.md. Do not load raw research or site dossiers. The Phase 5 corpus covers all 12 references but is not benchmark-validated; never fabricate intelligence to fill gaps.

### Select knowledge by fit, not resemblance

A card is eligible only when its causal job matches the project. Compare the project's audience, content, task frequency, risk, rendering limits, input modes, and responsive needs with the card's prerequisites and avoid conditions. Reject a visually tempting card when its costs or failure conditions conflict with project truth.

Translate selected principles through the direction contract. Preserve the causal relationship and vary the surface expression: layout, typography, imagery, motion, geometry, pacing, wording, control placement, and implementation technique. A result that visibly resembles a source is evidence that synthesis has failed, even if the source was never copied literally.

Keep a source ledger when cards materially shape a decision. Record why each card fits, which constraints apply, what was deliberately changed, and what evidence would cause removal. Do not cite a card as authority for a product fact or for an implementation mechanism it does not verify.

### 4. Implement with restraint

Respect the existing stack and choose the least complex technique that faithfully supports the direction. A library requires a concrete repeated or technically demanding need, measurable benefit, acceptable runtime/maintenance/privacy cost, fallback, and removal threshold. Build semantic structure and primary tasks before signature effects. Typography, spacing, hierarchy, and content must work without animation.

Treat expressiveness as independent axes: layout novelty, type assertiveness, visual richness, spatial depth, motion intensity, interaction novelty, narrative choreography, and information density. Apply different levels to task-critical, navigation, content, signature, and recovery zones. Experimental does not automatically mean WebGL, custom cursor, broken grid, or unusual navigation.

### Engineer motion as behavior

For every material motion unit, identify its purpose, trigger, input, state progression, mapping, timing, rendering class, lifecycle, fallback and removal condition. Prefer orientation, hierarchy, feedback or continuity over undirected spectacle. The interface's information structure and primary task must remain understandable when motion is removed.

Use familiar input semantics unless the direction genuinely requires a different mapping. If vertical scroll controls lateral or spatial progress, keep orientation and escape controls stable, preserve reversibility, provide keyboard and touch equivalents, and define a linear or reduced-motion path. Canvas or WebGL must not become the only carrier of essential meaning. Keep critical controls in semantic DOM where practical and budget asset, GPU, battery and failure costs explicitly.

Treat public library or bundle presence as an implementation signal only. It never proves that a specific effect uses that library. Verify what the rendered interface does, preserve plausible alternatives, and leave private mechanisms unknown.

For substantial existing-product changes, load behavior-preservation.md and record routes, flows, forms, auth/authorization boundaries, data contracts, states, keyboard behavior, responsive behavior, and tests that must survive.

### 5. Render and verify

When browser capability exists, substantial visual work is incomplete until the real interface is opened, interacted with, and inspected at representative desktop, tablet, and mobile sizes. Check primary routes and flows; reachable states; keyboard/focus; touch/coarse-pointer alternatives; reduced motion; content stress where relevant; console/runtime/hydration errors; failed requests; broken assets; loading/layout shift; and budgeted performance.

Capture a compact QA record using qa-evidence.md. Never claim visual verification when browser inspection did not occur. If tools are unavailable, report `not-visual-verified` and the strongest checks actually performed.

Verification language must match evidence. `Observed` means directly seen in a rendered state. `Recorded` adds a reproducible screenshot or frame sequence. `Measured` adds captured geometry, timing or another numeric value. `Implementation signal` identifies publicly delivered clues without feature attribution. `Implementation verified` requires direct evidence of the claimed mechanism. `Inferred` names a plausible explanation; it is never silently upgraded. `Unknown` stays unknown.

When a material check cannot run, describe the limitation and reduce the completion claim. Never allow a blocked reduced-motion, keyboard, responsive, runtime-error or primary-flow check to disappear inside an ordinary completion statement.

Critique the result as if another team made it: find generic, accidental, competing, unfinished, over-designed, under-designed, inaccessible, or purposeless choices. Convert material criticism into evidence-linked defects. Fix all blockers and major defects, then high-impact moderate defects. Stop when another pass produces no new blocker/major or high-value moderate work.

## Hard completion rules

- Preserve the user’s authorization boundary and unrelated work.
- Preserve established product language, behavior, routes, auth boundaries, and data contracts unless change is explicitly in scope.
- Keep controls discoverable and tasks complete across input modes and responsive states.
- Provide reduced-motion behavior for substantial animation.
- Do not add decorative data, claims, testimonials, or fake product states.
- Do not call visual work complete from code quality or compilation alone.
- Do not call this skill release-benchmark validated; its personal-beta installation does not replace isolated evaluation.

At handoff, lead with the outcome, name important changed files, state checks and browser evidence, disclose limitations, and distinguish observed facts from inferences.

---

## Source: `references/corpus/cards/anchored-editorial-irregularity.md`

---
id: card-anchored-editorial-irregularity
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-05, ref-07]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: de66066907d5ff9ab6e0e27762c5a5a0f04f2e9c44560de73eff4b98aadaf3e9
---

# Anchored editorial irregularity

Irregular scale, alignment, and cropping can signal curation when a quieter system supplies orientation. Use one or two stable anchors—section labels, a baseline, a repeated text measure, a persistent nav, or a predictable alternation—then vary media size and typographic placement around them. The anchor makes difference readable as intention; without it, the same variation becomes accidental noise.

This pattern suits portfolios, architecture, culture, and brand narratives where the work should not feel like interchangeable cards. First define the reading order in plain structure. Then decide which element remains stable while images, whitespace, or headline position vary. Let large type control pace only when the copy stays comprehensible and the mobile order is explicit. The purpose is not maximal difference on every section. It is a repeatable tension between one dependable rule and one changing axis.

Prerequisites: strong content hierarchy, meaningful media, a stable navigation route, and an editorial reason for variation. Costs: bespoke art direction, more responsive decisions, image-crop review, and longer visual QA. Failure conditions: every section invents a new grammar, labels become too quiet to perceive, reading order diverges from DOM order, or decorative line breaking damages comprehension.

Accessibility: maintain semantic headings and logical focus order independently of visual placement. Responsive: choose new crops and line breaks for narrow screens; do not preserve desktop emptiness at the cost of content. Performance: reserve dimensions for staggered media and avoid loading an entire portfolio at entry.

Anti-copy boundary: reuse the anchor-and-variation relationship only. Do not copy source typefaces, Spanish copy, black-and-white identity, project crops, loader treatment, or exact placements.

Decision profile: plausible families include CSS Grid, editorial flex layouts and art-directed media queries. A regular modular grid is the primary alternative and should win when comparison speed matters more than curation. Compatible with recurring proof and responsive substitution; conflicts with dense repeated controls. Variation axes: anchor, crop, scale, measure, cadence and alignment. Appropriate for authored narratives and portfolios; inappropriate for data tables, task queues and high-frequency workflows.

---

## Source: `references/corpus/cards/demonstration-before-decomposition.md`

---
id: card-demonstration-before-decomposition
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-11]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 77075edd6a2552e59fdc5857b940b59288a15efa2c69dac71b4c06206b3a8ee3
---

# Demonstration before decomposition

Show one representative workflow or outcome before presenting the capability taxonomy. The demonstration gives later labels a concrete referent; decomposition then helps users generalize beyond the example. The sequence should answer “what happens?” before “what are all the parts?” and then return to constraints, fit, or action.

Use this for new interaction paradigms, agentic tools, technical platforms, and products whose category language is still unstable. Pick a demonstration that reflects the core loop rather than an edge-case spectacle. Frame its start, intervention, and outcome. Follow it with a small capability vocabulary that maps directly back to observed moments. Provide a skip and a concise text summary for users who cannot or do not want to play media.

Prerequisites: an honest representative scenario, stable demo media, and a clear mapping from moments to capabilities. Costs: production, captions, updates as UI changes, and potential loading delay. Failure conditions: the demo is simulated without disclosure, hides setup or failure states, autoplays disruptive audio, or the subsequent taxonomy introduces unrelated claims.

Accessibility: include captions, transcript, controls, poster, and a structured textual walkthrough. Responsive: crop or recompose the demonstration while keeping key UI legible; provide still steps when video becomes unreadable. Performance: lazy-load below-the-fold media and reserve dimensions to avoid layout shifts.

Anti-copy boundary: reuse the demonstrate-then-name sequence only. Do not copy source product UI, icons, video framing, wording, monochrome styling, or capability order.

Decision profile: plausible families include captioned video, interactive walkthrough, annotated still sequence and live sandbox. A concise text example is the primary alternative and should win when media cost outweighs clarity. Compatible with recurring proof and semantic system objects; conflicts with unreproducible spectacle. Variation axes: scenario, medium, intervention points, taxonomy depth and skip path. Appropriate for unfamiliar workflows; inappropriate when the task is already well understood.

---

## Source: `references/corpus/cards/persistent-orientation-chrome.md`

---
id: card-persistent-orientation-chrome
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-03, ref-04]
observation_window: 2026-09-09T19:06:00+04:00/2026-09-09T19:40:00+04:00
confidence: high
promotion_hash: 9a9ada458acc3fde464e63a626a28a6604c3ae16dac204c90926d4a47935c302
---

# Persistent orientation chrome

When content moves along an unfamiliar axis or through a spatial scene, keep a small set of orientation and escape controls stable. A persistent identity cue, progress signal and next-or-exit action reduce the cognitive cost of expressive progression because the user does not have to relearn where they are or how to leave.

Use this for short editorial, lateral or spatial journeys whose movement is intentionally nonstandard. Keep the chrome quieter than the content, but make it semantically named and keyboard reachable. On mobile, substitute or simplify the controls if the desktop arrangement no longer fits; do not merely hide them.

Prerequisites: bounded scene count, explicit progress model and a conventional fallback path. Costs: fixed-screen space, layering complexity and extra responsive states. Failure conditions: unnamed controls, occluded content, misleading progress, no skip path, or persistent chrome that competes with the story.

Accessibility: expose progress and controls independently of visual location and honor reduced motion. Responsive: re-evaluate which controls must persist at each mode. Performance: keep the stable chrome DOM-based where practical so it remains available if a heavy scene fails.

Before adopting it, answer three questions: can a user identify current position without motion, can they reach the next meaningful destination with keyboard and touch, and can they exit the expressive sequence immediately? Remove or simplify the pattern if the answers depend on animation, hidden gestures or a functioning canvas. Verify orientation after every scene transition, not only at entry.

Anti-copy boundary: reuse the orientation principle only. Do not reproduce source logos, control placements, wording, palettes, camera paths or compositions.

Decision profile: plausible families include fixed semantic DOM, sticky section navigation and accessible progress controls. A conventional document outline is the primary alternative and should win when progression is not genuinely unusual. Compatible with responsive substitution, spatial closure and utility islands; conflicts with uninterrupted full-bleed content that cannot reserve safe space. Variation axes: cue type, persistence, edge, density and escape model. Appropriate for bounded nonstandard progression; inappropriate for ordinary pages.

---

## Source: `references/corpus/cards/recurring-proof-rhythm.md`

---
id: card-recurring-proof-rhythm
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-06, ref-11, ref-12]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 9806f3bb88bbcbc7e48819fe1987fc3af65af46415ff1eab045b43810d7b81dd
---

# Recurring proof rhythm

Alternate expressive claims with concrete proof at a repeatable cadence. A large promise earns attention, but a demonstration, project, metric, testimonial, or bounded offer should answer the next likely doubt before the page returns to atmosphere. Repetition creates trust because each expressive rise has an evidentiary landing. It also creates pacing: users can skim the proof points even when they do not follow every transition.

Use this for unfamiliar products, premium services, or founder-led brands where emotion and credibility both matter. Choose proof that matches the claim: show workflow for capability, outcomes for value, constraints for reliability, and examples for range. Keep each proof block independently understandable. Avoid decorative metrics and client logos that do not substantiate the adjacent statement.

Prerequisites: real evidence, a clear sequence of user questions, and permission to present the evidence accurately. Costs: content gathering, legal review, media production, and maintenance as facts age. Failure conditions: proof is vague, repeated modules become monotonous, animation delays access, or metrics lack context. A demonstration is not proof of general reliability; a single result is not a universal promise.

Accessibility: captions, transcripts, alt text, and text equivalents must carry the same claim as visual proof. Responsive: preserve claim-to-proof adjacency even when sticky layouts collapse. Performance: defer rich demonstrations, provide posters, and keep essential claims readable before media loads.

Anti-copy boundary: reuse the claim-to-proof cadence only. Do not borrow source metrics, testimonials, product UI, headlines, client marks, visual identity, or animation timing.

Decision profile: plausible families include alternating DOM sections, sticky claim/proof handoffs, inline demos and case-study modules. A compact evidence summary is the primary alternative and should win for urgent or repeat-use tasks. Compatible with demonstration-first and editorial cards; conflicts with unsupported marketing claims. Variation axes: evidence type, cadence, density, adjacency and reveal. Appropriate when trust must accumulate; inappropriate when no verified proof exists.

---

## Source: `references/corpus/cards/responsive-mode-substitution.md`

---
id: card-responsive-mode-substitution
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-01]
observation_window: 2026-09-09T18:42:00+04:00/2026-09-09T19:00:00+04:00
confidence: high
promotion_hash: d48ea984b65bca921e55451cff6e3cb0a64841d59f5c3264b38547c161a1d172
---

# Responsive mode substitution

When an expressive desktop system loses the space required for its hierarchy, substitute the coordinated interaction mode instead of shrinking every element. Change the navigation pattern, media crop or source, type layout and control density as one decision so the same priority survives at a different width.

Use this when a persistent rail, large spatial composition or media framing cannot remain legible and operable on a narrow viewport. First define what must remain invariant: task priority, route access, state clarity and essential evidence. Then design the smallest complete mobile mode that preserves those invariants.

Prerequisites: an explicit content hierarchy, representative viewport testing and separate asset/control decisions. Costs: more variants, asset weight and QA. Failure conditions: hidden destinations, a mobile mode with incomplete controls, cropped essential content, or source switching that causes loading regressions.

Accessibility: keep destinations, names and focus behavior equivalent. Responsive: test the actual rendered modes, not only breakpoint declarations. Performance: avoid downloading desktop and mobile media when only one is used.

Define invariants before variants: the primary claim, complete route access, control meaning and recovery path must survive every mode. Then choose which surface properties may change, such as crop, order, navigation container or motion. Remove the substitution if it creates duplicated content ownership, divergent capabilities or an untestable matrix; a fluid layout is preferable when it preserves the same priorities cleanly and reliably.

Anti-copy boundary: reuse the reasoning pattern only. Do not reproduce a source's navigation geometry, copy, imagery, color system or motion signature.

Decision profile: plausible families include CSS reflow, alternate DOM arrangements, art-directed media and progressive enhancement. A fluid layout is the primary alternative explanation and should win when it preserves all invariants. Compatible with orientation and proof cards; conflicts with any card that requires identical geometry across modes. Variation axes: order, crop, density, navigation container, motion and rendering class. Appropriate for a material mode change; inappropriate for minor breakpoint tuning.

---

## Source: `references/corpus/cards/semantic-system-object.md`

---
id: card-semantic-system-object
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-10]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: medium
promotion_hash: 44d317b8518dd78abca1729ad845c2e993fdf9df823ebc22e295056982f4638a
---

# Semantic system object

Represent a system with one coherent visual object, then provide a semantic decomposition beside or beneath it. Concentric rings, a map, a stack, a pipeline, or another domain-appropriate form can communicate relationships faster than a list. The object earns its place only if its geometry encodes a real distinction—sequence, containment, exchange, hierarchy, or state—and the equivalent meaning remains available without manipulation.

Use this for platforms whose value comes from connected parts rather than isolated features. Name the relationship before choosing the shape. Give the object a stable overview state, bounded interactions, and a textual inventory that follows the same model. If interaction reveals details, make each reveal reachable by keyboard and expose selected state programmatically.

Prerequisites: a defensible information model, few enough parts to remain legible, and an equivalent linear explanation. Costs: custom illustration or rendering, interaction semantics, responsive redesign, and maintenance when the product model changes. Failure conditions: geometry is arbitrary, labels require constant rotation, the object becomes a mystery-meat menu, or motion is the only explanation.

Accessibility: provide a heading, summary, ordered or grouped text, and named controls for every selectable region. Responsive: simplify labels, change representation, or move to a list rather than miniaturizing the desktop object. Performance: prefer SVG or DOM when sufficient and keep the semantic explanation independent of canvas.

Anti-copy boundary: reuse the one-object-plus-decomposition logic only. Do not copy source concentric rings, labels, monochrome identity, live status, brush marks, motion, or layout.

Decision profile: plausible families include semantic SVG, structured DOM diagrams, static illustration and progressively enhanced canvas. A grouped feature list is the primary alternative and should win when relationships are weak. Compatible with demonstration-first and responsive substitution; conflicts with arbitrary geometry or unlabeled hotspots. Variation axes: relationship type, shape, interaction depth, label strategy and fallback. Appropriate for a stable connected model; inappropriate for rapidly changing taxonomies.

---

## Source: `references/corpus/cards/spatial-tour-with-conventional-closure.md`

---
id: card-spatial-tour-with-conventional-closure
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-02]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: medium
promotion_hash: 304b0a57db7100b3225deb5d9d33414c74ad3cecc3f3df891586c60b72c8d4f0
---

# Spatial tour with conventional closure

When a product benefits from spatial exploration, keep the expressive tour bounded and close it with conventional decision content. The unusual progression earns attention and demonstrates character; familiar pricing, FAQs, contact, or comparison restores scanning speed when the user is ready to decide. The relationship matters more than either surface alone: exploration builds a mental model, while the conventional close prevents the interaction model from becoming a tax on every task.

Use this when a small set of capabilities can be represented as memorable stations and the audience has time to explore. Establish a stable coordinate, progress, or section cue before movement begins. Make every station reachable by more than a hidden gesture, preserve a linear semantic reading order, and let users jump directly to the practical close. On narrow screens, replace the spatial mechanism if it no longer fits; preserve the station sequence and route access.

Prerequisites: a short scene inventory, clear orientation, semantic content outside the rendering surface, and a conventional exit. Costs: interaction teaching, responsive variants, asset loading, and additional accessibility QA. Failure conditions: the tour hides essential facts, traps keyboard users, implies false geography, or forces motion on users who prefer less.

Accessibility: expose station names, current position, skip controls, focus order, and a reduced-motion linear path. Responsive: allow a vertical or paged substitute rather than compressing a desktop coordinate field. Performance: keep decision content independent of the richest rendering layer so it survives failure.

Anti-copy boundary: reuse the exploration-to-closure relationship only. Do not reuse source coordinates, grid appearance, illustrations, feature names, colors, copy, or scene choreography.

Decision profile: plausible families include native paged sections, transformed DOM, SVG maps and hybrid canvas with DOM stations. An ordinary feature sequence is the primary alternative and should win when exploration adds no understanding. Compatible with orientation chrome and responsive substitution; conflicts with dense reference tasks. Variation axes: station count, axis, progress cue, close type and fallback. Appropriate for short exploratory stories; inappropriate when facts must be scanned immediately.

---

## Source: `references/corpus/cards/utility-islands-over-immersion.md`

---
id: card-utility-islands-over-immersion
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-08, ref-09]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 776716b8e43780cf4d5a3ed11eb21362d18e9cac318db8465fb4f20b99e67e2a
---

# Utility islands over immersion

Place critical actions in independently legible utility islands around an immersive media field. Each island owns one job—identity, primary navigation, contact, status, sound, or progress—and maintains sufficient contrast regardless of the scene beneath it. The media supplies atmosphere; the islands preserve task completion. This differs from generic floating cards because placement follows persistent interface responsibility, not decoration.

Use this when a full-viewport video, canvas, or richly layered image is central to the proposition. Limit the number of islands and rank them. Identity and escape should remain stable; secondary status can yield on narrow screens. If an island changes state, name the state directly. Sound must begin off or by explicit consent.

Prerequisites: a simple action model, robust contrast treatment, safe-area rules, and a semantic layer independent of the rendered scene. Costs: z-index and collision management, breakpoint-specific placement, backdrop testing, and focus treatment. Failure conditions: islands cover focal content, controls resemble decoration, the scene failure removes navigation, or mobile stacking consumes most of the viewport.

Accessibility: use native controls, visible focus, unambiguous names, state announcements, and a bypass around the immersive region. Responsive: consolidate secondary islands into a complete menu while retaining primary action and escape. Performance: render islands in resilient DOM and load them before or independently from expensive media.

Anti-copy boundary: reuse the responsibility-based island system only. Do not copy source HUD frames, panel shapes, microcopy, atmospheric footage, sound treatment, palettes, or exact corner placements.

Decision profile: plausible families include fixed DOM controls, sticky toolbars, safe-area overlays and progressive enhancement over video or canvas. A conventional header and content column is the primary alternative and should win when immersion is secondary. Compatible with orientation and responsive substitution; conflicts with uncontrolled overlays. Variation axes: responsibility, edge, consolidation, contrast field and persistence. Appropriate for one dominant immersive stage; inappropriate for dense multi-task applications.

---

## Source: `references/corpus/index.md`

# Validated Corpus Index

Status: Personal beta — skill-assisted development smoke-tested, non-isolated, non-blinded, and not release-benchmark validated. Eight causal cards are routable; no release claim has been made.

This root is a router, not a design encyclopedia. Project truth, existing behavior, platform foundations, accessibility and performance always win. Load no more than three cards and at most one vocabulary module for ordinary synthesis.

## Route

1. Name the design job and the user's next unresolved question.
2. Reject cards whose prerequisites, content needs, costs or avoid conditions conflict with the project.
3. Choose one primary relationship; optionally add one orientation/responsive card and one proof card.
4. Record selected and rejected IDs in the project source ledger.
5. Transform content role, sequence, scale, medium, interaction and responsive behavior. Never imitate a source composition.

## Cards

All entries are fresh as of the listed observation window in each card.

| Card | Decision / project condition | Axes and content need | Render / cost | Constraints and avoid | Sources |
|---|---|---|---|---|---:|
| Responsive mode substitution | Can the same priority survive by changing mode? Desktop cannot shrink intact. | Order, crop, density; explicit invariants | CSS/DOM/media; medium | Preserve all routes and controls; avoid when fluid reflow works | 1 |
| Persistent orientation chrome | How will users know position and exit? Progression is nonstandard and bounded. | Cue, persistence, escape; scene map | semantic DOM over any scene; medium | Keyboard, touch, reduced motion; avoid ordinary pages | 2 |
| Spatial tour with conventional closure | Should exploration lead to a scannable decision close? Few memorable stations exist. | Axis, stations, close; practical FAQ/pricing/action | DOM/SVG/hybrid; high | Linear fallback and direct close; avoid dense reference tasks | 1 |
| Anchored editorial irregularity | Which stable rule makes variation feel intentional? Authored media supports curation. | Scale, crop, alignment; meaningful portfolio content | CSS Grid/media; medium | DOM order and mobile crops; avoid repeated task controls | 2 |
| Recurring proof rhythm | What evidence resolves each expressive claim? Verified proof is available. | Cadence, adjacency, evidence type; demos/results/constraints | DOM/media; medium | Contextualize claims; avoid when proof is unavailable | 3 |
| Utility islands over immersion | Which interface responsibilities must survive active media? One scene dominates. | Edge, contrast, consolidation; identity/actions/status | DOM over video/canvas; high | Focus, safe areas, failure fallback; avoid dense apps | 2 |
| Semantic system object | Does one geometry explain a real relationship? The product has a stable connected model. | Shape, labels, detail; equivalent textual decomposition | SVG/DOM/canvas; high | Named regions and list fallback; avoid arbitrary taxonomies | 1 |
| Demonstration before decomposition | Should users see the unfamiliar loop before learning its vocabulary? A representative scenario exists. | Scenario, medium, taxonomy; honest workflow evidence | video/stills/live demo; medium | Captions, transcript, skip; avoid unreproducible spectacle | 1 |

## Vocabulary

Load structure and composition, typography and content, visual material and depth, or interaction and state only when that domain dominates. Load motion only when motion is material.

## Size and sharding

Keep this root within 300–700 words. Seven required selection simulations routed accurately within this budget, so no shard is justified. If a later pilot cannot route validated cards accurately, shard by stable design job or domain and load this tiny root plus at most one relevant shard. Never expand the root into a design encyclopedia.

---

## Source: `references/corpus/provenance.md`

# Runtime Corpus Provenance

Corpus version: `0.5-phase5`

This runtime uses two-level provenance.

## Level 1 — runtime provenance summary

Each card contains stable source IDs, corpus version, observation window, confidence and a SHA-256 promotion hash. The hash is calculated over the UTF-8 card with its `promotion_hash` value normalized to 64 zeroes. This summary supports routing and integrity checks without exposing development-only paths.

- `card-anchored-editorial-irregularity`: sources `ref-05, ref-07`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `de66066907d5ff9ab6e0e27762c5a5a0f04f2e9c44560de73eff4b98aadaf3e9`.
- `card-demonstration-before-decomposition`: sources `ref-11`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `77075edd6a2552e59fdc5857b940b59288a15efa2c69dac71b4c06206b3a8ee3`.
- `card-persistent-orientation-chrome`: sources `ref-03, ref-04`; observation window `2026-09-09T19:06:00+04:00/2026-09-09T19:40:00+04:00`; confidence `high`; promotion hash `9a9ada458acc3fde464e63a626a28a6604c3ae16dac204c90926d4a47935c302`.
- `card-recurring-proof-rhythm`: sources `ref-06, ref-11, ref-12`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `9806f3bb88bbcbc7e48819fe1987fc3af65af46415ff1eab045b43810d7b81dd`.
- `card-responsive-mode-substitution`: sources `ref-01`; observation window `2026-09-09T18:42:00+04:00/2026-09-09T19:00:00+04:00`; confidence `high`; promotion hash `d48ea984b65bca921e55451cff6e3cb0a64841d59f5c3264b38547c161a1d172`.
- `card-semantic-system-object`: sources `ref-10`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `medium`; promotion hash `44d317b8518dd78abca1729ad845c2e993fdf9df823ebc22e295056982f4638a`.
- `card-spatial-tour-with-conventional-closure`: sources `ref-02`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `medium`; promotion hash `304b0a57db7100b3225deb5d9d33414c74ad3cecc3f3df891586c60b72c8d4f0`.
- `card-utility-islands-over-immersion`: sources `ref-08, ref-09`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `776716b8e43780cf4d5a3ed11eb21362d18e9cac318db8465fb4f20b99e67e2a`.

The distributed runtime contains no absolute or relative filesystem links to an undistributed development harness.

## Level 2 — development-harness evidence trace

The archived harness retains screenshots, interaction sequences, measurements, findings, claim audits, limitations, promotion decisions and resolvable raw-evidence pointers. Stable source and evidence IDs connect the two levels. Full evidence paths remain inside that archive and are intentionally absent from runtime context.

---

## Source: `references/corpus/vocabulary/interaction-state.md`

# Interaction and state vocabulary

Use this module when the key design question is navigation, state feedback, spatial progression, or the relationship between immersive behavior and ordinary controls.

## Make the interaction model explicit

A user should be able to answer: where am I, what can I do, what changed, and how do I leave? For conventional pages, native scroll and links usually answer these questions. For lateral, virtual, or scene-based experiences, load **persistent orientation chrome** and define current position, progress, next action, skip, and exit. Directory or visual placement alone is not a control model; semantics and behavior must agree.

**Spatial tour with conventional closure** is useful when exploration is part of understanding but purchasing or evaluation still needs fast scanning. Keep the tour bounded, expose stations, and provide direct access to pricing, FAQ, contact, or comparison. Do not make practical content depend on completing the tour.

**Utility islands over immersion** helps distribute stable responsibilities around a full-viewport scene. Identity, navigation, sound, contact, and status should each have clear state and contrast. Consolidate secondary responsibilities on small screens without removing routes. Sound begins off and changes only through an explicit named control.

## State contract

For every control, specify idle, hover where applicable, focus-visible, active/pressed, loading, success, error, disabled, and reduced-motion behavior. Use visible text or standard semantics for state; do not rely on color, position, or animation alone. Preserve focus when menus open or close and return it predictably. Escape should dismiss temporary layers.

## Input equivalence

Wheel, pointer, touch, keyboard, and assistive technology do not produce identical events. Define the user intent—advance, select, inspect, dismiss—then support it across relevant inputs. A swipe-only scene needs buttons or links. A hover reveal needs focus and tap behavior. Scroll-jacking must never prevent reversal, browser shortcuts, or access to content.

## Responsive behavior

Load **responsive mode substitution** when the interaction grammar itself must change. A desktop spatial rail can become a mobile list; a field of utility islands can become a header plus complete menu; an animated diagram can become ordered steps. Test that every route and action survives the substitution.

## Failure boundary

Reject a novel interaction if users must guess the gesture, if the semantic order differs from the apparent order, if a renderer failure removes essential actions, or if reduced motion means missing content. The expressive layer should enhance a complete interaction model, not serve as its only implementation.

## Map state before polish

Create a state table for each material component. Include entry condition, available actions, resulting state, visible feedback, announced feedback, focus destination, persistence, escape, and failure recovery. This is especially important for menus, dialogs, filters, media controls, carousels, forms, and spatial scenes. A beautiful transition cannot compensate for an undefined state edge.

Use native platform behavior where it already expresses the intent. Links navigate, buttons cause actions, form controls expose values, and headings organize content. Custom cursor treatments, drag regions, and rendered hotspots are optional layers; they do not replace standard semantics. When a visual object is selectable, expose its selected state and equivalent text control.

Loading deserves explicit interaction policy. Prevent duplicate submissions without trapping the user, retain entered data through recoverable failures, and distinguish background loading from a blocked task. Optimistic feedback needs a rollback state. Animation may bridge state changes, but the end state must be immediately knowable when motion is absent.

Verify interruption: open a menu, resize; begin a transition, press Escape; scroll a virtual scene backward; background and restore the tab; rotate a touch device; trigger validation with keyboard only. Confirm that focus is neither lost nor moved behind an overlay. Test browser back and deep links where state affects navigation.

For small fixes, do not invent a new interaction system. Repair the bounded state while preserving surrounding behavior. For substantial existing-project work, load the behavior-preservation schema and record which routes, tasks, data and keyboard behaviors cannot regress before changing visual state.

---

## Source: `references/corpus/vocabulary/motion.md`

# Motion vocabulary

Load this module only when motion is materially required by the project. Motion must serve orientation, hierarchy, feedback, continuity, narrative, atmosphere, or bounded delight. If its purpose cannot be named, use a static treatment.

## Select by purpose

For orientation, use **persistent orientation chrome** around nonstandard progression. The chrome itself should move minimally; its stability is the point. For hierarchy, use restrained chapter handoffs or demonstration sequencing. For narrative, **spatial tour with conventional closure** can stage a short journey, but practical content must remain directly reachable. For atmosphere, **utility islands over immersion** keeps active media from erasing usability. For explanation, **demonstration before decomposition** uses temporal evidence before abstract labels.

## Behavior model before easing

Specify trigger, input, state progression, mapping, timing status, rendering class, lifecycle, fallback, and reduced-motion result. “Smooth scroll” or “cinematic” is not a behavior model. Decide whether motion is time-driven, input-driven, or state-driven. Input-driven motion needs clamping, reversal, and device normalization. State-driven motion needs a clear start and end state. Time-driven ambient motion needs pause rules.

## Timing vocabulary

Use short transitions for feedback, medium transitions for spatial continuity, and longer sequences only for intentional narrative. Exact duration should be tuned in the real interface. Easing should reflect the physical or attentional relationship: quick deceleration for direct manipulation, symmetric ease for neutral continuity, and linear mapping for progress that must track input. Avoid chaining delays that make content wait for decoration.

## Reduced motion

Reduced motion is a designed state, not animation set to zero everywhere. Preserve hierarchy and causality: replace parallax with static depth, spatial travel with cuts or fades, letter sequencing with complete text, and auto-rotating objects with a stable overview plus controls. Never remove content, progress, or feedback. If the environment cannot demonstrate the reduced-motion behavior, record it as blocked and do not claim completion.

## Performance lifecycle

Prefer transform and opacity for DOM motion, but still measure. Pause video, canvas, and requestAnimationFrame work when offscreen or hidden. Respect device capability and data-saving contexts. Use posters and deterministic first frames. Avoid stacking multiple continuously animated layers beneath blur or blend modes without profiling.

## Verification

Test first load, interruption, reversal, resize, orientation change, keyboard operation, touch, background-tab return, media failure, and reduced motion. Motion is accepted only when it improves the named purpose without weakening comprehension, input access, or performance. Source choreography, timing signatures, particles, camera paths, and branded transitions remain outside the transfer boundary.

## Motion unit contract

Treat each substantial effect as a unit with an owner and a removal threshold. Record purpose, trigger, source input, start and end states, progress mapping, duration status, easing status, rendering layer, lifecycle, accessibility behavior, and fallback. Separate directly observed behavior from inferred implementation. A public bundle name is a signal, not proof that the effect uses it.

Coordinate units at the page level. One dominant narrative motion can coexist with small feedback transitions, but several competing scroll mappings will fracture attention. Define which unit owns the scroll signal, which elements are passive followers, and which controls remain stable. Avoid nested smooth-scrolling systems or independent animation loops unless measurement justifies them.

Interruption is a design state. User input should be able to reverse or complete direct manipulation without waiting for a queued timeline. Route changes and modal opens should cancel irrelevant work. Resizing must recompute geometry without jumping past content. When hydration or media loading finishes late, it should not replay an entrance that moves content under the user's pointer.

Set budgets in terms the project can verify: number and size of media assets, concurrent videos, long tasks, layout shifts, frame stability, battery-sensitive loops, and fallback behavior. Match the sophistication of the technique to the available QA. A modest DOM transition with complete input and reduced-motion coverage is preferable to an untestable rendered spectacle.

During critique, temporarily remove each motion unit. If hierarchy, orientation, feedback, continuity, narrative, atmosphere, or delight does not materially worsen, remove the unit permanently. This deletion test is the strongest defense against motion that exists only to resemble a reference.

---

## Source: `references/corpus/vocabulary/structure-composition.md`

# Structure and composition vocabulary

Use this module after the corpus index when the design problem is primarily page sequence, spatial organization, or hierarchy. It routes among causal cards; it does not add source evidence.

## Start with the user's next question

Choose the next section by the doubt it must resolve. If an expressive claim needs credibility, route to **recurring proof rhythm**. If an unfamiliar interaction needs a safe landing, route to **spatial tour with conventional closure**. If the material itself should feel curated rather than catalogued, consider **anchored editorial irregularity**. The question-to-section relationship is the structure; visual styling follows it.

## Stable rule versus changing axis

Art-directed composition usually needs one stable rule. That rule may be a grid line, reading measure, section label, navigation position, or repeated claim-to-proof cadence. Vary one dominant axis around it: scale, crop, alignment, density, or scene depth. When three or more axes change together, add a stronger anchor or simplify. Load **persistent orientation chrome** when the changing axis is movement itself.

## Sequence patterns

- Promise → demonstration → decomposition → fit/action: use for an unfamiliar product. Load **demonstration before decomposition**, optionally followed by **recurring proof rhythm**.
- Atmosphere → project/result → atmosphere → project/result: use for premium or founder-led services. Load **recurring proof rhythm**.
- Overview object → selected part → textual inventory: use when the offer is a connected system. Load **semantic system object**.
- Expressive stations → practical comparison or FAQ: use for bounded exploration. Load **spatial tour with conventional closure**.

## Composition checks

The visual order and DOM order should tell the same story. Every oversized field needs a reason: emphasis, pause, comparison, or immersion. Empty space must preserve hierarchy rather than postpone information. Sticky or fixed layers must release before they collide with the next responsibility. On mobile, recompose; do not preserve desktop irregularity by forcing tiny type, horizontal overflow, or excessive blank space.

## Combination rule

Ordinarily load no more than three cards. One card should own sequence, one may own orientation or responsive substitution, and one may own proof. If two cards dictate the same section behavior, keep the more specific one. Document rejected cards in the project selection rather than blending every idea.

## Failure boundary

Reject expressive composition when it obscures task priority, makes the route dependent on canvas, breaks semantic order, or requires more content than the project has. The corpus supplies options, never permission to weaken product truth.

## Practical composition pass

Before drawing sections, write the task spine as verbs: understand, compare, inspect, decide, recover. Attach one content responsibility to each verb. Then sketch the least expressive sequence that completes it. Only after that baseline is coherent should a card alter pacing or space. This keeps novelty attached to a real transition instead of spreading it evenly across the page.

Test the sequence at three levels. At page level, confirm that the opening promise and final action agree. At section level, confirm that every scene resolves one question and creates at most one new one. At viewport level, confirm that the dominant element, supporting explanation, and next action can coexist without ambiguous priority. A sticky region should announce why it persists and when it releases.

For existing products, preservation comes first. Map current routes, forms, states, and repeated components before moving content. A new composition may change visual grouping without changing task order, or may change sequence only when the user authorizes that behavioral impact. Record which choice was made.

Use content stress tests before approval: a short title, a long title, missing media, an error state, localization expansion, and a narrow viewport. If the composition works only with ideal copy and perfect images, it is a poster rather than a durable interface. The final direction should name both the stable structural rule and the deliberately varied axis so implementation and critique have a shared standard.

---

## Source: `references/corpus/vocabulary/typography-content.md`

# Typography and content vocabulary

Use this module when the central decision concerns reading pace, claim hierarchy, editorial voice, or the relationship between expressive type and evidence.

## Typography has a job

Name the job before selecting a type treatment: announce, orient, explain, compare, prove, or invite action. Display scale is justified when it creates a meaningful pause or establishes a proposition. Dense supporting type is justified when it increases decision value. If a line break, letter animation, or unusual alignment does neither, remove it.

**Anchored editorial irregularity** is relevant when typography and imagery should feel composed rather than templated. Keep semantic headings intact, select a stable measure or alignment, then vary scale or placement. Do not copy a source typeface or headline shape. On narrow screens, write new line breaks and preserve the intended reading order.

## Claims need adjacent proof

Use **recurring proof rhythm** when bold language risks outrunning evidence. Pair capability claims with demonstrations, value claims with contextualized outcomes, reliability claims with constraints or process, and range claims with representative work. A logo wall is trust context, not proof of a specific outcome. A metric needs scope and provenance.

For unfamiliar products, **demonstration before decomposition** can reduce jargon. Begin with a short statement of the user's goal, show a representative loop, and only then name the component capabilities. The labels should map back to the example; otherwise the decomposition is a second unrelated pitch.

## Pace controls

Pace comes from sentence length, line measure, contrast, whitespace, repetition, and reveal order—not only animation. Use large statements sparingly so each retains signal. Follow an emotional line with a concrete sentence that clarifies audience, action, or evidence. Let utility copy remain conventional even inside an expressive frame. Navigation, consent, errors, pricing, and form instructions should not become riddles.

## Accessible expression

Never split text into letters or duplicate visual layers without verifying the accessibility tree. Preserve a clean semantic string, language metadata, zoom behavior, and contrast. If a moving headline is material, provide a static reduced-motion state that shows the complete thought. Avoid justified or excessively narrow text that creates rivers or difficult tracking.

## Selection questions

Ask: What must the user remember? What must they understand? What must they trust? What action follows? Choose one expressive typographic device for the memory job, a quiet system for understanding, and explicit evidence for trust. If the same device tries to do all three, it will usually become noisy.

Reject any treatment that depends on copied wording, damages comprehension, or produces a semantic tree more chaotic than the visual result warrants.

## Build a functional type system

Define roles before sizes: display proposition, section claim, reading text, evidence label, metadata, control, and status. Assign each role a consistent family, weight range, measure, and contrast. A project rarely needs a separate visual treatment for every section. Distinction can come from scale and spacing while the role system stays stable.

Set readable defaults first. Body copy should tolerate browser zoom and localization. Controls need adequate size and clear verbs. Metadata may be quieter, but it must remain legible where it carries dates, prices, progress, or qualifications. Test mixed case, numerals, punctuation, and long unbroken strings; a typeface that looks strong in one hero word may fail in product content.

Content hierarchy should survive without layout. Read headings and paragraphs in DOM order. If the narrative becomes incoherent, repair the information model rather than relying on placement or animation. Avoid duplicated live text used solely for visual effects. When duplicates are unavoidable, expose one canonical semantic string and hide purely visual copies correctly.

For major direction work, record a content contract: primary proposition, evidence types, required caveats, calls to action, and prohibited invented claims. Typography should amplify this contract. It must not smuggle in unsupported confidence through oversized numbers, fabricated social proof, or vague superlatives.

During critique, remove one type treatment and see whether hierarchy improves. If it does, the removed treatment was competing rather than contributing. Approve the system only after desktop and mobile line breaks, zoom, focus indicators, loading substitutions, and error messages have all been seen in the rendered interface.

---

## Source: `references/corpus/vocabulary/visual-material-depth.md`

# Visual material and depth vocabulary

Use this module when imagery, rendered surfaces, texture, or spatial layering is material to the direction. It helps decide how much immersion the product can support and which stable interface layer must remain above it.

## Choose the medium by responsibility

Use ordinary images when the job is evidence, comparison, or editorial pacing. Use video when temporal change is itself the evidence or atmosphere. Use SVG when a system diagram needs scalable labels and semantic support. Use Canvas or WebGL only when continuous spatial transformation or rendering is essential to the proposition. A technically expensive medium is not automatically more expressive.

**Semantic system object** helps when one visual form must explain connected parts. The geometry must encode a real relationship, and a textual decomposition must carry equivalent meaning. If an SVG can do the job, prefer it over canvas because focus, labels, responsiveness, and failure handling are easier.

**Utility islands over immersion** applies when media owns most of the viewport. Keep identity, primary action, navigation, status, and escape in resilient, high-contrast DOM layers. Each island should have one responsibility and remain legible against the worst frame, not only the hero poster. Avoid scattering decorative cards around a scene.

## Depth ladder

Build depth in a deliberate order: base color or image, content field, local overlays, persistent utility, temporary modal. Document which layer can occlude another. Sticky chapters need release points; fixed controls need safe-area and collision rules. Blur, grain, halftone, glow, and blend modes can support atmosphere, but they should not reduce text contrast or imply interaction where none exists.

## Evidence and atmosphere

Atmospheric media should not carry factual content alone. Pair it with visible text or a later proof block. Use **recurring proof rhythm** when the experience needs to alternate feeling and evidence. Keep posters, captions, alt text, and outcome context available before rich media completes.

## Responsive transformation

Reframe rather than shrink. Change crop, replace ambient video with a still, simplify a system object, consolidate utility islands, or move from spatial depth to a vertical sequence. Preserve the proposition and actions, not every decorative layer. Test portrait devices where background focal points and persistent controls compete most severely.

## Performance and failure

Reserve dimensions, compress and size assets, defer offscreen media, stop animation in hidden tabs, and provide a meaningful no-canvas state. Set a budget before adopting multiple video or WebGL layers. Verify the experience under slow loading and media failure. Reject depth that removes navigation when a renderer fails or consumes the budget without improving comprehension, trust, orientation, or delight.

## Material direction contract

For each visual medium, record its content role, focal subject, crop behavior, loading state, fallback, rights or provenance, and removal condition. This prevents the asset list from becoming a moodboard with no implementation responsibility. A hero video may establish place; project images may prove range; a diagram may explain structure. If two media layers have the same role, remove or combine one.

Depth should clarify hierarchy through occlusion, scale, focus, or motion, but never conceal the task. Decide where text sits when the background reaches its lightest, darkest, and busiest frames. Use protective fields, scrims, or dedicated surfaces based on those worst cases. Validate forced-colors and reduced-transparency contexts where relevant rather than assuming a blend mode will survive.

Treat loading as part of the composition. A poster, reserved aspect ratio, skeleton, or quiet color field should preserve the intended hierarchy before rich media arrives. Loader branding may create continuity, but it cannot indefinitely block navigation or content. Timeouts and retry states need ordinary language.

For existing projects, inventory current asset URLs, intrinsic dimensions, CMS crops, and caching behavior before replacement. Preserve SEO-relevant alt text and structured content unless scope explicitly changes them. For greenfield work, use placeholders only as clearly labeled implementation scaffolding and never present them as finished product evidence.

Approve the material system after testing normal, slow, failed, paused, and reduced-motion states. If the static fallback feels like a broken version of the concept, the concept is too dependent on the rendering layer and should be simplified.

---

## Source: `references/delivery/browser-qa.md`

# Browser QA

Load before claiming completion of substantial visual work.

## Evidence loop

`RUN → OPEN → INSPECT → INTERACT → RESIZE → CHECK STATES → CHECK RUNTIME → CRITIQUE → FIX → REGRESS`

Freeze representative sizes from project requirements. If none exist, use desktop `1440×900`, tablet `1024×768`, and mobile `390×844`; add a narrow stress width or real device when material.

Record routes/flows, browser/device/input, viewport, states, screenshots, recordings for material motion, keyboard/focus, touch/coarse-pointer alternative, reduced motion, zoom/reflow and content stress where relevant, console/hydration errors, failed requests, broken assets, loading/layout shift, budgeted performance, defects, fixes, regression checks, and limitations using `../schemas/qa-evidence.md`.

One modern engine is enough for routine iteration only when no support matrix, advanced/high-risk browser feature, or browser-specific symptom requires more. Use a secondary engine when declared support or advanced CSS/SVG/font/scroll/WebGL/media/input behavior creates risk. Use a real device when touch gesture, soft keyboard, mobile viewport chrome, sensor/media policy, mobile GPU, or low-power performance is central. Otherwise record the limitation.

Severity:

- S0: primary task, data/security, key viewport, or critical accessibility blocker.
- S1: serious task, hierarchy, interaction, responsive, accessibility, runtime, or performance defect.
- S2: visible issue materially reducing quality.
- S3: low-impact refinement.

No unresolved S0/S1 may remain. Fix high-impact S2. Stop when the evidence record is complete and another pass finds no new S0/S1 or high-value S2.

If browser inspection did not occur, use `not-visual-verified`. Compilation, screenshots supplied by someone else, or static review do not prove live behavior.

---

## Source: `references/delivery/frontend-and-regression.md`

# Frontend and Regression Safeguards

Load for substantial implementation, especially existing-product work.

- Respect project instructions, framework, package manager, routing, styling, state ownership, tests, and component conventions.
- Model semantic structure and behavior before visual wrappers.
- Preserve deep links, browser navigation, titles, focus restoration, forms, validation, pending/duplicate prevention, success/failure recovery, authentication/authorization boundaries, data contracts, and required analytics.
- Keep authoritative or sensitive work on the correct server/client side; do not move trust to the browser for design convenience.
- Cover reachable loading, empty, success, warning, error, disabled, selected, active, hover, and focus states.
- Define tokens for stable repeated decisions. Do not flatten a deliberate one-off composition into a generic variant, or duplicate system tokens without reason.
- Structure advanced animation so setup, input mapping, interruption, visibility, resize, and cleanup remain reviewable.
- Check build/type/test plus browser console, hydration/runtime errors, requests, and assets.
- Record asset source and licensing. Review privacy effects of analytics, embeds, remote fonts/media, trackers, CDNs, and third-party libraries.
- Prefer progressive enhancement and graceful degradation for unavailable JavaScript/APIs, failed heavy assets, reduced motion, low power, and constrained networks when the product permits.

For every new dependency record the exact problem, why current capability is insufficient, bundle/runtime/maintenance/privacy cost, accessibility/browser risk, fallback, success measure, and removal threshold. Remove it if it duplicates current capability, solves a trivial isolated effect, breaks degradation, exceeds budget, or provides no measured improvement.

Use the behavior-preservation schema for substantial existing-project changes and verify affected invariants after implementation.

---

## Source: `references/delivery/responsive-accessibility-performance.md`

# Responsive, Accessibility, and Performance

## Responsive composition

For every major section define invariant purpose; hierarchy at each composition state; grid, order, type measure, imagery crop, navigation/control, density, whitespace, and interaction transformation; pointer-to-touch alternative; motion reduction; and fallback. Add breakpoints when content or interaction fails, not because a framework supplies one. Inspect rendered desktop, tablet, mobile, and a stress width where material.

## Accessibility

Use the project’s applicable standard, normally an AA-level baseline unless stricter. Protect semantic landmarks/headings, labels, names/states, reading order, keyboard operation, visible focus, contrast/non-color cues, target sizing, zoom/reflow, dynamic announcements, dialog/menu/route focus management, media alternatives, and error recovery. Substantial motion needs reduced-motion behavior. Hover/pointer-only information needs touch and keyboard access.

Accessibility changes the design from the beginning; it is not a finishing patch. Replace a distinctive choice if it depends on exclusion.

## Performance

Set project-specific budgets before high-cost creative work. Track media/model/texture and font strategy, JavaScript/hydration, main-thread work, frame stability, memory/GPU, layout stability, interaction response, and expected low-end/mobile behavior.

For every expensive feature record:

`purpose → expected value → cost → measurement → fallback → removal threshold`

Size and lazy-load noncritical media, preserve stable layout, batch DOM reads/writes, pause hidden work, and clean up resources. Measure instead of assuming compositing or frame quality. If the effect harms the primary task on an expected device, simplify or remove it.

---

## Source: `references/intelligence/motion-selection-and-engineering.md`

# Motion Selection and Engineering

Load only when motion or spatial rendering is material.

## Model before library

For each motion unit define:

`PURPOSE → TRIGGER → INPUT → STATE → NORMALIZATION → MAPPING → INTERPOLATION → TIMING → SEQUENCING → RENDERING → LIFECYCLE → PERFORMANCE → ACCESSIBILITY → ABSTRACTION`

Purpose must be orientation, hierarchy, feedback, continuity, narrative, atmosphere, or appropriate delight. If no purpose survives, remove the effect.

Specify rest/start/end states, activation threshold, raw input range, clamp/dead zones, output properties, coordinate space, transform origin, interruption, reversal, repeat, resize, route exit, visibility, and cleanup. Separate observable behavior from inferred implementation.

## Rendering choice

- CSS transitions/keyframes: predictable local state and simple loops.
- Web Animations API: programmatic native playback/cancellation.
- DOM plus `requestAnimationFrame`: custom continuous input mapping when layout work is controlled.
- SVG: paths, masks, diagrams, and resolution-independent vector effects.
- Canvas 2D: many drawn 2D objects or pixel/generative work that does not require semantic DOM nodes.
- WebGL/Three.js: true spatial scenes, shaders, camera work, or high object counts central to meaning.
- A motion/timeline library: repeated state orchestration or complex synchronized sequences, not one hover.

Choose the least complex faithful mechanism. Library detection in a bundle is only an implementation signal; it does not prove that library drives a specific effect.

## Safety and lifecycle

Prefer task-complete settled states. Provide reduced-motion behavior that preserves hierarchy and causality. Replace pointer-only effects for touch/coarse pointer. Pause hidden/offscreen work, avoid layout thrashing, dispose listeners/observers/timelines/textures/geometries/renderers, handle context loss where relevant, and define low-power/mobile fallbacks.

Animation must remain coherent under rapid interaction, interruption, reverse navigation, resize, and content changes. Measure frame/runtime cost when motion is substantial; remove or simplify a signature effect that harms the primary task.

---

## Source: `references/intelligence/originality-and-anti-generic.md`

# Originality and Anti-Generic Review

Originality means project specificity, not arbitrary novelty.

## Generic test

Ask whether the experience could belong to 100 unrelated organizations after changing only the logo and accent color. Inspect concept, information sequence, hero logic, grid, component grammar, typography, imagery/data, copy structure, interaction, and motion.

Warnings include an unjustified centered hero; repeated rounded cards; purple/blue AI palette; gradients, glow, blur, pills, and floating badges by default; identical section rhythm; decorative dashboards or metrics; generic stock imagery; weak typography; all content fading upward; and large empty space without compositional purpose. A warning is not a ban: keep a familiar pattern when content and task justify it.

## Source ledger and transformation

When a reference or causal card materially influences a signature choice, record it using `../schemas/source-ledger.md`. State the abstract principle, project problem, selected relationship, transformations, rejected source-specific elements, resulting decision, and distance risk.

Transform context and relationship set—not only colors. Review overall silhouette, information sequence, dominant grid/composition, type behavior, imagery treatment, motifs, navigation, signature interaction, motion choreography, and their combination. Remove logo, copy, and accent color mentally; if the result remains recognizably derived from one source, redesign it.

Familiar navigation, form, control, focus, trust, and task conventions should remain when they improve usability or accessibility. Never introduce UX friction just to look original.

---

## Source: `references/intelligence/synthesis-and-expressiveness.md`

# Synthesis and Expressiveness

## Direction synthesis

Combine project truth, task spine, content structure, brand equities, platform foundations, technical constraints, interview signals, and only relevant validated corpus intelligence. Generate two or three internal candidates that differ in organizing idea and relationship set—not merely color. Evaluate task fit, content fit, trust, specificity, responsive resilience, accessibility, runtime feasibility, originality distance, and strength without motion. Select one and record it in the direction contract.

Project-specific concepts come from real nouns, verbs, tensions, materials, rhythms, user emotions, and behaviors. Translate one dominant concept into relationships across composition, typography, imagery/data, interaction, and pacing. Use few supporting signatures and keep utility zones calm.

## Expressive profile

Rate these axes independently from 0–4 as a thinking aid: layout novelty, typography assertiveness, visual richness, spatial depth, motion intensity, interaction novelty, narrative choreography, and information density.

Apply ceilings from task criticality, trust/error cost, session frequency, content stability, brand permission, expected devices/input, accessibility, performance, and delivery budget.

Assign zones:

- task-critical: maximum clarity, low interference;
- navigation/orientation: stable and recognisable;
- content/narrative: expression that aids pacing and comprehension;
- signature: concentrated creative ambition;
- system/recovery: calm, explicit, robust.

High visual richness need not mean high motion. Dense data need not mean generic styling. Experimental storytelling can keep escape, navigation, and fallback conventional.

## System relationships

Treat typography, spacing, hierarchy, composition, color, imagery, depth, states, and motion as relationships. Ask why each combination works, what prerequisite it assumes, what it costs, and when it fails. If a design decision cannot connect to project truth, platform foundations, or a direction-contract role, reconsider it.

---

## Source: `references/schemas/behavior-preservation.md`

# Behavior Preservation Schema

Load only for substantial existing-project changes. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/behavior-preservation.md`.

```yaml
schema_version: 1
behavior_preservation:
  run_id: required-string
  project_revision: required-string
  permitted_change_distance: polish | evolution | reinterpretation | explicit-replacement
  invariants:
    routes_and_navigation: [record]
    primary_flows: [record]
    forms_submission_and_recovery: [record]
    authentication_authorization_boundaries: [record]
    data_and_server_contracts: [record]
    loading_empty_success_failure_states: [record]
    keyboard_focus_and_assistive_behavior: [record]
    responsive_and_input_mode_behavior: [record]
    analytics_or_required_instrumentation: [record]
    public_component_or_api_contracts: [record]
  invariant_record:
    id: required-string
    description: required-string
    evidence_or_check: required-string
    change_authorized: required-boolean
    result: pending | preserved | intentionally-changed | failed | blocked
  tests_and_manual_checks: [required-string]
  explicitly_authorized_changes: [string]
  created_at: required-ISO-8601
```

If a design conflicts with an invariant, adapt it or obtain explicit scope. Visual improvement alone does not authorize a behavior change.

---

## Source: `references/schemas/direction-contract.md`

# Direction Contract Schema

Use for greenfield work or a major redesign. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/direction-contract.md`.

```yaml
schema_version: 1
direction_contract:
  run_id: required-string
  contract_version: positive-integer
  project_truth_summary: required-string
  authority_conflicts_and_resolution: [string]
  primary_task_spine: [required-string]
  audience_and_trust_context: required-string
  experience_thesis: required-string
  emotional_target: [required-string]
  concept_seed: required-string
  composition_logic: required-string
  information_and_content_pacing: required-string
  typography_behavior: required-string
  palette_and_material_behavior: required-string
  imagery_or_data_treatment: required-string
  interaction_roles: [string]
  motion_roles: [string]
  expressive_profile:
    layout_novelty: integer-0-to-4
    typography_assertiveness: integer-0-to-4
    visual_richness: integer-0-to-4
    spatial_depth: integer-0-to-4
    motion_intensity: integer-0-to-4
    interaction_novelty: integer-0-to-4
    narrative_choreography: integer-0-to-4
    information_density: integer-0-to-4
  page_zones: [required-string]
  signature_moments: [string]
  utility_zone_rules: [required-string]
  responsive_transformations: [required-string]
  accessibility_invariants: [required-string]
  performance_budget_and_fallbacks: [required-string]
  implementation_strategy: required-string
  exclusions_not_this: [required-string]
  selected_intelligence_ids: [string]
  assumptions_and_confidence: [string]
  material_risks_and_prototypes: [string]
  created_at: required-ISO-8601
```

Version only when a consequential discovery changes the direction. Raw interview answers must be translated into design consequences.

---

## Source: `references/schemas/project-selection.md`

# Project Selection Schema

Create only when validated corpus intelligence is used. Canonical task artifact: `<task-artifacts>/creative-web-design/<run-id>/project-selection.md`.

```yaml
schema_version: 1
project_selection:
  run_id: required-string
  project_problem: required-string
  authority_constraints:
    project_truth: [required-string]
    platform_foundations: [required-string]
  considered:
    - intelligence_id: required-string
      version: required-string
      decision: selected | rejected
      rationale: required-string
      project_fit: required-string
      conflicts_or_costs: [string]
      confidence: high | medium | low
  selected_relationships: [required-string]
  unresolved_questions: [string]
  created_at: required-ISO-8601
```

Rules: select at most three causal cards during ordinary synthesis; every selection must solve a named project problem; rejected ideas remain concise; no raw site evidence or harness paths appear here.

---

## Source: `references/schemas/qa-evidence.md`

# QA Evidence Schema

Use for substantial visual work when browser tooling exists. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/qa/qa-evidence.md`.

```yaml
schema_version: 1
qa_evidence:
  run_id: required-string
  implementation_version: required-string
  tested_at: required-ISO-8601
  environments: [required-environment-record]
  routes_and_flows: [required-result-record]
  state_coverage: [result-record]
  screenshots: [evidence-pointer]
  recordings: [evidence-pointer]
  keyboard_and_visible_focus: [result-record]
  touch_or_coarse_pointer_alternatives: [result-record]
  reduced_motion: [result-record]
  zoom_and_reflow: [result-record]
  content_stress:
    long_content: [result-record]
    localization_or_long_labels: [result-record]
  runtime:
    console_errors: [string]
    failed_requests: [string]
    broken_assets: [string]
    hydration_errors: [string]
    loading_observations: [string]
    layout_shift_observations: [string]
    budgeted_performance_measurements: [measurement-record]
  defects:
    - id: required-string
      severity: S0 | S1 | S2 | S3
      evidence: [evidence-pointer]
      diagnosis: required-string
      fix: string-or-null
      regression_check: string-or-null
      status: open | fixed | accepted-limitation
  remaining_limitations: [string]
  verification_claim: visual-verified | partially-verified | not-visual-verified
```

Never use `visual-verified` without direct browser inspection. No unresolved S0/S1 may remain at completion.

---

## Source: `references/schemas/source-ledger.md`

# Source Ledger Schema

Create when a reference or causal card materially affects a signature decision. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/source-ledger.md`.

```yaml
schema_version: 1
source_ledger:
  run_id: required-string
  influences:
    - source_id: required-string
      source_version: string-or-null
      abstract_principle: required-string
      project_problem: required-string
      selected_relationship: required-string
      transformations_applied: [required-string]
      rejected_source_specific_elements: [string]
      resulting_project_specific_decision: required-string
      distance_risk: low | medium | high
  dominance_review:
    single_source_dominates_relationship_set: required-boolean
    debranded_resemblance: low | medium | high
    action: accept | revise
    rationale: required-string
  created_at: required-ISO-8601
```

Use stable runtime IDs, versions, and promotion hashes. Do not put broken paths to an undistributed research harness in runtime artifacts.

---

## Source: `references/workflows/existing-project.md`

# Existing Project Workflow

Inspect before questioning or redesigning.

## Two truths

Repository truth covers instructions, routes, components, tokens, fonts, assets, dependencies, state ownership, forms, auth boundaries, tests, build commands, and conventions. Rendered truth covers actual hierarchy, spacing, content, navigation, interaction, motion, responsive transformation, loading/error states, console failures, and brand impression.

## Sequence

1. Read project instructions and map the relevant repository surface.
2. Run the current interface when possible and inspect affected flows at representative viewports.
3. Record brand equities, behavior invariants, technical boundaries, and visible defects.
4. Classify material elements as `preserve`, `improve`, `replace`, or `unresolved`, with evidence and risk.
5. Infer permitted change distance from the request. Ask only if ambiguity would materially change the outcome.
6. For substantial changes, load `../schemas/behavior-preservation.md` before editing.
7. Establish direction without erasing recognisable product concepts or breaking the task model.
8. Implement in risk order and verify affected invariants after each material slice.
9. Run browser QA, senior critique, regression checks, and repository checks.

“Replace” requires authorization and a stronger reason than personal preference. Visual improvement does not authorize changing routes, product language, data behavior, authentication, permissions, analytics contracts, or public APIs.

If the browser is unavailable, make the strongest static and test-based assessment possible, explicitly record the gap, and do not claim rendered inspection.

---

## Source: `references/workflows/greenfield.md`

# Greenfield Workflow

Load for a new website, product interface, or major page without an established direction.

1. Establish purpose, audience, primary and secondary tasks, trust/error stakes, content, brand inputs, delivery environment, devices, accessibility needs, and performance constraints.
2. Use the interview gate only for remaining material uncertainty.
3. Define information architecture, page progression, and task spine before component styling.
4. Create the direction contract: experience thesis, project-specific concept, composition, type roles, palette/material behavior, imagery/data treatment, interaction and motion roles, expressive axes/zones, responsive transformations, accessibility invariants, budgets, fallbacks, and exclusions.
5. Prototype the highest-risk assumption first: unusual composition, content scale, interaction, motion mapping, rendering path, or mobile transformation.
6. Implement semantic task structure before signature expression. Establish only tokens and primitives that are genuinely shared.
7. Render early. Inspect desktop and mobile before the page feels “finished”; adjust direction when content or browser evidence disproves it.
8. Complete states, keyboard/touch behavior, reduced motion, graceful degradation, and performance. For a supplied flow, preserve the exact meaning of each action when transferring it into implementation. When a brief names distinct demo states, render a materially distinct, observable state for each one; a control label or explanatory note alone is not state coverage.
9. Run senior critique and severity-based browser QA.

Do not begin with a default centered hero, repeated cards, gradient/glow system, or fashionable library. Derive form from project content, behavior, brand, and emotional target. A direction should still communicate hierarchy and identity with motion disabled.

---

## Source: `references/workflows/interview-and-direction.md`

# Interview and Direction

Load this only for substantial greenfield work or a major redesign with unresolved creative decisions.

## Question gate

Ask zero questions for small fixes, fully specified work, or safe “choose for me.” Otherwise rank candidate uncertainties from 0–3 on design impact, genuine uncertainty, downstream breadth, and risk of being wrong; subtract inferability from existing evidence and user effort. Discard a question when the repository, rendered product, brief, content, or conversation already answers it, or when plausible answers would not change the direction contract.

Ask two to four high-information questions. A single blocking question is acceptable when everything else is specified. Stop before four when remaining uncertainty is low; reopen only for a newly discovered consequential conflict.

Questions should be project-specific comparisons with clear consequences. They may blend answers and include “use your judgment.” Avoid vague style labels or choosing technologies as proxies for experiences.

Examples to adapt, never repeat mechanically:

- For an urgent information page: immediate action first or explanation first; institutional or warmer clinical voice; mandatory always-visible content.
- For a repeat-use dashboard: fastest repeated decision; simultaneous density or progressive detail; permitted navigation change distance.
- For an editorial property experience: imagery, material detail, or place story as lead; quiet or selective cinematic pacing; whether supplied assets support full-viewport use.
- For education: independent practice, guided instruction, or assigned work; calm or playful feedback; student reading level.

## Answer conversion

Do not store only option letters. Translate each answer into affected decisions and constraints. For example, “immediate action first” changes information order, first-viewport hierarchy, CTA priority, and motion restraint. Resolve conflicts using project truth, then platform foundations, then corpus knowledge.

## Choose-for-me

Infer purpose, audience, task criticality, trust, content readiness, brand maturity, frequency, expected devices, and accessibility/performance ceilings. Generate two or three internal organizing ideas that differ in content/composition logic, select the strongest, state a concise thesis and material assumptions, then proceed. Do not ask for approval of routine design choices.

## Required artifact

For major work create a direction contract using `../schemas/direction-contract.md`. If corpus intelligence influences it, also create project selection and source ledger records. Version the contract only when a consequential discovery changes the direction.
