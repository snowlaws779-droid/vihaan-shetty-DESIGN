---
name: vihaan-shetty-design
description: Design, redesign, implement, and visually verify project-specific websites and web interfaces. Use for substantial frontend design work, art direction, interaction or motion systems, or visual implementation; keep small fixes small and do not use this as a generic coding or teaching skill.
metadata:
  status: personal-beta
---

# Vihaan-Shetty-DESIGN

This is a **personal beta — skill-assisted development smoke-tested, non-isolated, non-blinded, and not release-benchmark validated**. Do not publish or describe it as release-benchmark validated.

## Authority

Resolve every decision in this order:

1. **Project truth** — user scope, content, audience, brand, behavior, repository, constraints, and real data.
2. **Platform foundations** — semantics, established controls, accessibility, responsive behavior, performance, browser/input realities, privacy, and graceful degradation.
3. **Creative corpus** — validated causal design intelligence. It expands vocabulary but never overrides the first two authorities.

Never invent product proof, data, functionality, reference mechanics, or authorization. Do not copy reference branding, text, assets, distinctive compositions, or substantial code.

## Classify the task

Before loading supporting material, classify the request:

- **Small fix:** bounded spacing, contrast, overlap, responsive, state, or animation repair. Make the narrow change; ask no design interview.
- **Existing-product change:** inspect repository and rendered product before questions or direction. Read [existing-project.md](references/workflows/existing-project.md). For a substantial change also read [frontend-and-regression.md](references/delivery/frontend-and-regression.md).
- **Greenfield or major new page:** establish purpose, content, task spine, constraints, and material unknowns. Read [greenfield.md](references/workflows/greenfield.md).
- **Major direction/redesign:** read [interview-and-direction.md](references/workflows/interview-and-direction.md), [synthesis-and-expressiveness.md](references/intelligence/synthesis-and-expressiveness.md), and [originality-and-anti-generic.md](references/intelligence/originality-and-anti-generic.md).
- **Material motion, Canvas, or WebGL:** additionally read [motion-selection-and-engineering.md](references/intelligence/motion-selection-and-engineering.md).
- **Substantial implementation:** read [responsive-accessibility-performance.md](references/delivery/responsive-accessibility-performance.md).
- **Rendered verification:** read [browser-qa.md](references/delivery/browser-qa.md).
- **QA, critique, or audit only:** inspect the supplied implementation and load only the relevant delivery reference; do not invent a redesign mandate.

Do not load all references. Load whole focused files only when their trigger applies.

## Operating loop

Use the smallest applicable portion of:

`UNDERSTAND → RESOLVE MATERIAL UNCERTAINTY → OBSERVE → MODEL RELATIONSHIPS → SYNTHESIZE → COMMIT → IMPLEMENT → RENDER → INSPECT → CRITIQUE → REFINE → VERIFY`

### 1. Understand before styling

Identify the primary user outcome, audience, trust/error stakes, content structure, brand equities, repeat-use pattern, supported devices, and delivery constraints. In an existing project, inspect routes, components, tokens, assets, dependencies, states, tests, and project instructions. Run the current interface when possible.

### 2. Ask only consequential questions

Ask zero questions for small fixes, fully specified tasks, or safe “choose for me” requests. Otherwise, for substantial greenfield work or a major redesign, ask two to four project-specific comparative questions only if answers would materially change the direction. Never ask what the brief, repository, conversation, or rendered product already answers. Stop early when remaining uncertainty is low. Reopen questions only for a newly discovered consequential conflict.

### 3. Commit to a direction

For major work, create a direction contract using [direction-contract.md](references/schemas/direction-contract.md). Establish task spine, experience thesis, concept seed, composition, typography, content/imagery treatment, interaction and motion roles, expressive profile, responsive transformations, accessibility invariants, performance limits, fallbacks, and explicit “not this” boundaries.

If corpus knowledge is used, read the compact [corpus index](references/corpus/index.md), select at most three relevant validated cards, and load at most one vocabulary module. Record the decision using [project-selection.md](references/schemas/project-selection.md) and [source-ledger.md](references/schemas/source-ledger.md). Do not load raw research or site dossiers. The Phase 5 corpus covers all 12 references but is not benchmark-validated; never fabricate intelligence to fill gaps.

### Select knowledge by fit, not resemblance

A card is eligible only when its causal job matches the project. Compare the project's audience, content, task frequency, risk, rendering limits, input modes, and responsive needs with the card's prerequisites and avoid conditions. Reject a visually tempting card when its costs or failure conditions conflict with project truth.

Translate selected principles through the direction contract. Preserve the causal relationship and vary the surface expression: layout, typography, imagery, motion, geometry, pacing, wording, control placement, and implementation technique. A result that visibly resembles a source is evidence that synthesis has failed, even if the source was never copied literally.

Keep a source ledger when cards materially shape a decision. Record why each card fits, which constraints apply, what was deliberately changed, and what evidence would cause removal. Do not cite a card as authority for a product fact or for an implementation mechanism it does not verify.

### 4. Implement with restraint

Respect the existing stack and choose the least complex technique that faithfully supports the direction. A library requires a concrete repeated or technically demanding need, measurable benefit, acceptable runtime/maintenance/privacy cost, fallback, and removal threshold. Build semantic structure and primary tasks before signature effects. Typography, spacing, hierarchy, and content must work without animation.

Treat expressiveness as independent axes: layout novelty, type assertiveness, visual richness, spatial depth, motion intensity, interaction novelty, narrative choreography, and information density. Apply different levels to task-critical, navigation, content, signature, and recovery zones. Experimental does not automatically mean WebGL, custom cursor, broken grid, or unusual navigation.

### Engineer motion as behavior

For every material motion unit, identify its purpose, trigger, input, state progression, mapping, timing, rendering class, lifecycle, fallback and removal condition. Prefer orientation, hierarchy, feedback or continuity over undirected spectacle. The interface's information structure and primary task must remain understandable when motion is removed.

Use familiar input semantics unless the direction genuinely requires a different mapping. If vertical scroll controls lateral or spatial progress, keep orientation and escape controls stable, preserve reversibility, provide keyboard and touch equivalents, and define a linear or reduced-motion path. Canvas or WebGL must not become the only carrier of essential meaning. Keep critical controls in semantic DOM where practical and budget asset, GPU, battery and failure costs explicitly.

Treat public library or bundle presence as an implementation signal only. It never proves that a specific effect uses that library. Verify what the rendered interface does, preserve plausible alternatives, and leave private mechanisms unknown.

For substantial existing-product changes, load [behavior-preservation.md](references/schemas/behavior-preservation.md) and record routes, flows, forms, auth/authorization boundaries, data contracts, states, keyboard behavior, responsive behavior, and tests that must survive.

### 5. Render and verify

When browser capability exists, substantial visual work is incomplete until the real interface is opened, interacted with, and inspected at representative desktop, tablet, and mobile sizes. Check primary routes and flows; reachable states; keyboard/focus; touch/coarse-pointer alternatives; reduced motion; content stress where relevant; console/runtime/hydration errors; failed requests; broken assets; loading/layout shift; and budgeted performance.

Capture a compact QA record using [qa-evidence.md](references/schemas/qa-evidence.md). Never claim visual verification when browser inspection did not occur. If tools are unavailable, report `not-visual-verified` and the strongest checks actually performed.

Verification language must match evidence. `Observed` means directly seen in a rendered state. `Recorded` adds a reproducible screenshot or frame sequence. `Measured` adds captured geometry, timing or another numeric value. `Implementation signal` identifies publicly delivered clues without feature attribution. `Implementation verified` requires direct evidence of the claimed mechanism. `Inferred` names a plausible explanation; it is never silently upgraded. `Unknown` stays unknown.

When a material check cannot run, describe the limitation and reduce the completion claim. Never allow a blocked reduced-motion, keyboard, responsive, runtime-error or primary-flow check to disappear inside an ordinary completion statement.

Critique the result as if another team made it: find generic, accidental, competing, unfinished, over-designed, under-designed, inaccessible, or purposeless choices. Convert material criticism into evidence-linked defects. Fix all blockers and major defects, then high-impact moderate defects. Stop when another pass produces no new blocker/major or high-value moderate work.

## Hard completion rules

- Preserve the user’s authorization boundary and unrelated work.
- Preserve established product language, behavior, routes, auth boundaries, and data contracts unless change is explicitly in scope.
- Keep controls discoverable and tasks complete across input modes and responsive states.
- Provide reduced-motion behavior for substantial animation.
- Do not add decorative data, claims, testimonials, or fake product states.
- Do not call visual work complete from code quality or compilation alone.
- Do not call this skill release-benchmark validated; its personal-beta installation does not replace isolated evaluation.

At handoff, lead with the outcome, name important changed files, state checks and browser evidence, disclose limitations, and distinguish observed facts from inferences.
