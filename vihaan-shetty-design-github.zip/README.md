# Vihaan-Shetty-DESIGN

`Vihaan-Shetty-DESIGN` is a reusable web-design intelligence package for substantial website and interface work. It helps an agent inspect a real product, resolve only material uncertainty, form an original direction, implement with appropriate frontend engineering, and verify the result in a browser.

## What to use

- **Codex:** install or copy this repository's contents into `~/.codex/skills/vihaan-shetty-design/`, then invoke `$vihaan-shetty-design`.
- **Other models:** upload or attach [UNIVERSAL_WEB_DESIGN_SKILL.md](UNIVERSAL_WEB_DESIGN_SKILL.md), then ask the model to follow it for the current web-design task. It is the complete portable, model-agnostic instruction set.

The native Codex package is intentionally progressive: `SKILL.md` directs Codex to load only the relevant material under `references/`. The universal file is flattened so models without a skill-loader can use the same guidance from one upload.

## What it covers

- Context-sensitive 0–4-question discovery for substantial work.
- Existing-product, greenfield, redesign, motion, and QA workflows.
- Causal design synthesis from a 12-reference corpus without copying its brands, layouts, text, assets, or distinctive compositions.
- Motion/Canvas/WebGL decision-making, lifecycle, accessibility, fallback, and removal criteria.
- Responsive behavior, semantic HTML, keyboard and touch paths, performance constraints, and regression preservation.
- Browser-based render, inspect, critique, refine, and evidence-linked verification.

## Status and limits

This is a **personal beta**. It was skill-assisted development smoke-tested, but the smoke work was non-isolated and non-blinded. It is **not release-benchmark validated**. Do not claim formal benchmark results, benchmark superiority, or verified causation for a particular reference site's private implementation.

The package does not invent product facts, proof, data, functionality, or authorization. It should never replace project requirements, accessibility, privacy, platform realities, or a real browser QA pass.

## Repository layout

```text
SKILL.md                         Native Codex entrypoint
agents/openai.yaml               Codex presentation metadata
references/                      Progressive supporting guidance and schemas
UNIVERSAL_WEB_DESIGN_SKILL.md    Full one-file edition for other models
CHECKSUMS.sha256                 SHA-256 inventory of the export
```

No private research, source-site dossiers, evaluation fixtures, runner archives, or hidden-rubric materials are included.

## GitHub upload

Create an empty GitHub repository, then upload the contents of this folder (not the parent `outputs` directory). GitHub will render this README automatically. No license is included because ownership and reuse terms should be chosen by the repository owner.
