# Motion Selection and Engineering

Load only when motion or spatial rendering is material.

## Model before library

For each motion unit define:

`PURPOSE → TRIGGER → INPUT → STATE → NORMALIZATION → MAPPING → INTERPOLATION → TIMING → SEQUENCING → RENDERING → LIFECYCLE → PERFORMANCE → ACCESSIBILITY → ABSTRACTION`

Purpose must be orientation, hierarchy, feedback, continuity, narrative, atmosphere, or appropriate delight. If no purpose survives, remove the effect.

Specify rest/start/end states, activation threshold, raw input range, clamp/dead zones, output properties, coordinate space, transform origin, interruption, reversal, repeat, resize, route exit, visibility, and cleanup. Separate observable behavior from inferred implementation.

## Rendering choice

- CSS transitions/keyframes: predictable local state and simple loops.
- Web Animations API: programmatic native playback/cancellation.
- DOM plus `requestAnimationFrame`: custom continuous input mapping when layout work is controlled.
- SVG: paths, masks, diagrams, and resolution-independent vector effects.
- Canvas 2D: many drawn 2D objects or pixel/generative work that does not require semantic DOM nodes.
- WebGL/Three.js: true spatial scenes, shaders, camera work, or high object counts central to meaning.
- A motion/timeline library: repeated state orchestration or complex synchronized sequences, not one hover.

Choose the least complex faithful mechanism. Library detection in a bundle is only an implementation signal; it does not prove that library drives a specific effect.

## Safety and lifecycle

Prefer task-complete settled states. Provide reduced-motion behavior that preserves hierarchy and causality. Replace pointer-only effects for touch/coarse pointer. Pause hidden/offscreen work, avoid layout thrashing, dispose listeners/observers/timelines/textures/geometries/renderers, handle context loss where relevant, and define low-power/mobile fallbacks.

Animation must remain coherent under rapid interaction, interruption, reverse navigation, resize, and content changes. Measure frame/runtime cost when motion is substantial; remove or simplify a signature effect that harms the primary task.
