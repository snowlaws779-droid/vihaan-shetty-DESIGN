# Originality and Anti-Generic Review

Originality means project specificity, not arbitrary novelty.

## Generic test

Ask whether the experience could belong to 100 unrelated organizations after changing only the logo and accent color. Inspect concept, information sequence, hero logic, grid, component grammar, typography, imagery/data, copy structure, interaction, and motion.

Warnings include an unjustified centered hero; repeated rounded cards; purple/blue AI palette; gradients, glow, blur, pills, and floating badges by default; identical section rhythm; decorative dashboards or metrics; generic stock imagery; weak typography; all content fading upward; and large empty space without compositional purpose. A warning is not a ban: keep a familiar pattern when content and task justify it.

## Source ledger and transformation

When a reference or causal card materially influences a signature choice, record it using `../schemas/source-ledger.md`. State the abstract principle, project problem, selected relationship, transformations, rejected source-specific elements, resulting decision, and distance risk.

Transform context and relationship set—not only colors. Review overall silhouette, information sequence, dominant grid/composition, type behavior, imagery treatment, motifs, navigation, signature interaction, motion choreography, and their combination. Remove logo, copy, and accent color mentally; if the result remains recognizably derived from one source, redesign it.

Familiar navigation, form, control, focus, trust, and task conventions should remain when they improve usability or accessibility. Never introduce UX friction just to look original.
