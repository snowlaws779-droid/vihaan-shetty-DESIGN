# Synthesis and Expressiveness

## Direction synthesis

Combine project truth, task spine, content structure, brand equities, platform foundations, technical constraints, interview signals, and only relevant validated corpus intelligence. Generate two or three internal candidates that differ in organizing idea and relationship set—not merely color. Evaluate task fit, content fit, trust, specificity, responsive resilience, accessibility, runtime feasibility, originality distance, and strength without motion. Select one and record it in the direction contract.

Project-specific concepts come from real nouns, verbs, tensions, materials, rhythms, user emotions, and behaviors. Translate one dominant concept into relationships across composition, typography, imagery/data, interaction, and pacing. Use few supporting signatures and keep utility zones calm.

## Expressive profile

Rate these axes independently from 0–4 as a thinking aid: layout novelty, typography assertiveness, visual richness, spatial depth, motion intensity, interaction novelty, narrative choreography, and information density.

Apply ceilings from task criticality, trust/error cost, session frequency, content stability, brand permission, expected devices/input, accessibility, performance, and delivery budget.

Assign zones:

- task-critical: maximum clarity, low interference;
- navigation/orientation: stable and recognisable;
- content/narrative: expression that aids pacing and comprehension;
- signature: concentrated creative ambition;
- system/recovery: calm, explicit, robust.

High visual richness need not mean high motion. Dense data need not mean generic styling. Experimental storytelling can keep escape, navigation, and fallback conventional.

## System relationships

Treat typography, spacing, hierarchy, composition, color, imagery, depth, states, and motion as relationships. Ask why each combination works, what prerequisite it assumes, what it costs, and when it fails. If a design decision cannot connect to project truth, platform foundations, or a direction-contract role, reconsider it.
