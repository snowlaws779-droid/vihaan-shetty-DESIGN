# QA Evidence Schema

Use for substantial visual work when browser tooling exists. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/qa/qa-evidence.md`.

```yaml
schema_version: 1
qa_evidence:
  run_id: required-string
  implementation_version: required-string
  tested_at: required-ISO-8601
  environments: [required-environment-record]
  routes_and_flows: [required-result-record]
  state_coverage: [result-record]
  screenshots: [evidence-pointer]
  recordings: [evidence-pointer]
  keyboard_and_visible_focus: [result-record]
  touch_or_coarse_pointer_alternatives: [result-record]
  reduced_motion: [result-record]
  zoom_and_reflow: [result-record]
  content_stress:
    long_content: [result-record]
    localization_or_long_labels: [result-record]
  runtime:
    console_errors: [string]
    failed_requests: [string]
    broken_assets: [string]
    hydration_errors: [string]
    loading_observations: [string]
    layout_shift_observations: [string]
    budgeted_performance_measurements: [measurement-record]
  defects:
    - id: required-string
      severity: S0 | S1 | S2 | S3
      evidence: [evidence-pointer]
      diagnosis: required-string
      fix: string-or-null
      regression_check: string-or-null
      status: open | fixed | accepted-limitation
  remaining_limitations: [string]
  verification_claim: visual-verified | partially-verified | not-visual-verified
```

Never use `visual-verified` without direct browser inspection. No unresolved S0/S1 may remain at completion.
