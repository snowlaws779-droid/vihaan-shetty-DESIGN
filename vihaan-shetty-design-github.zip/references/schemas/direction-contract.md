# Direction Contract Schema

Use for greenfield work or a major redesign. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/direction-contract.md`.

```yaml
schema_version: 1
direction_contract:
  run_id: required-string
  contract_version: positive-integer
  project_truth_summary: required-string
  authority_conflicts_and_resolution: [string]
  primary_task_spine: [required-string]
  audience_and_trust_context: required-string
  experience_thesis: required-string
  emotional_target: [required-string]
  concept_seed: required-string
  composition_logic: required-string
  information_and_content_pacing: required-string
  typography_behavior: required-string
  palette_and_material_behavior: required-string
  imagery_or_data_treatment: required-string
  interaction_roles: [string]
  motion_roles: [string]
  expressive_profile:
    layout_novelty: integer-0-to-4
    typography_assertiveness: integer-0-to-4
    visual_richness: integer-0-to-4
    spatial_depth: integer-0-to-4
    motion_intensity: integer-0-to-4
    interaction_novelty: integer-0-to-4
    narrative_choreography: integer-0-to-4
    information_density: integer-0-to-4
  page_zones: [required-string]
  signature_moments: [string]
  utility_zone_rules: [required-string]
  responsive_transformations: [required-string]
  accessibility_invariants: [required-string]
  performance_budget_and_fallbacks: [required-string]
  implementation_strategy: required-string
  exclusions_not_this: [required-string]
  selected_intelligence_ids: [string]
  assumptions_and_confidence: [string]
  material_risks_and_prototypes: [string]
  created_at: required-ISO-8601
```

Version only when a consequential discovery changes the direction. Raw interview answers must be translated into design consequences.
