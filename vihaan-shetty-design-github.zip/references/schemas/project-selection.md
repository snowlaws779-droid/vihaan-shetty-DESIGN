# Project Selection Schema

Create only when validated corpus intelligence is used. Canonical task artifact: `<task-artifacts>/creative-web-design/<run-id>/project-selection.md`.

```yaml
schema_version: 1
project_selection:
  run_id: required-string
  project_problem: required-string
  authority_constraints:
    project_truth: [required-string]
    platform_foundations: [required-string]
  considered:
    - intelligence_id: required-string
      version: required-string
      decision: selected | rejected
      rationale: required-string
      project_fit: required-string
      conflicts_or_costs: [string]
      confidence: high | medium | low
  selected_relationships: [required-string]
  unresolved_questions: [string]
  created_at: required-ISO-8601
```

Rules: select at most three causal cards during ordinary synthesis; every selection must solve a named project problem; rejected ideas remain concise; no raw site evidence or harness paths appear here.
