# Source Ledger Schema

Create when a reference or causal card materially affects a signature decision. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/source-ledger.md`.

```yaml
schema_version: 1
source_ledger:
  run_id: required-string
  influences:
    - source_id: required-string
      source_version: string-or-null
      abstract_principle: required-string
      project_problem: required-string
      selected_relationship: required-string
      transformations_applied: [required-string]
      rejected_source_specific_elements: [string]
      resulting_project_specific_decision: required-string
      distance_risk: low | medium | high
  dominance_review:
    single_source_dominates_relationship_set: required-boolean
    debranded_resemblance: low | medium | high
    action: accept | revise
    rationale: required-string
  created_at: required-ISO-8601
```

Use stable runtime IDs, versions, and promotion hashes. Do not put broken paths to an undistributed research harness in runtime artifacts.
