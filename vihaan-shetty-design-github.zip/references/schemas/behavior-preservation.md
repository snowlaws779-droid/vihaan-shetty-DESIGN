# Behavior Preservation Schema

Load only for substantial existing-project changes. Canonical artifact: `<task-artifacts>/creative-web-design/<run-id>/behavior-preservation.md`.

```yaml
schema_version: 1
behavior_preservation:
  run_id: required-string
  project_revision: required-string
  permitted_change_distance: polish | evolution | reinterpretation | explicit-replacement
  invariants:
    routes_and_navigation: [record]
    primary_flows: [record]
    forms_submission_and_recovery: [record]
    authentication_authorization_boundaries: [record]
    data_and_server_contracts: [record]
    loading_empty_success_failure_states: [record]
    keyboard_focus_and_assistive_behavior: [record]
    responsive_and_input_mode_behavior: [record]
    analytics_or_required_instrumentation: [record]
    public_component_or_api_contracts: [record]
  invariant_record:
    id: required-string
    description: required-string
    evidence_or_check: required-string
    change_authorized: required-boolean
    result: pending | preserved | intentionally-changed | failed | blocked
  tests_and_manual_checks: [required-string]
  explicitly_authorized_changes: [string]
  created_at: required-ISO-8601
```

If a design conflicts with an invariant, adapt it or obtain explicit scope. Visual improvement alone does not authorize a behavior change.
