# Validated Corpus Index

Status: Personal beta — skill-assisted development smoke-tested, non-isolated, non-blinded, and not release-benchmark validated. Eight causal cards are routable; no release claim has been made.

This root is a router, not a design encyclopedia. Project truth, existing behavior, platform foundations, accessibility and performance always win. Load no more than three cards and at most one vocabulary module for ordinary synthesis.

## Route

1. Name the design job and the user's next unresolved question.
2. Reject cards whose prerequisites, content needs, costs or avoid conditions conflict with the project.
3. Choose one primary relationship; optionally add one orientation/responsive card and one proof card.
4. Record selected and rejected IDs in the project source ledger.
5. Transform content role, sequence, scale, medium, interaction and responsive behavior. Never imitate a source composition.

## Cards

All entries are fresh as of the listed observation window in each card.

| Card | Decision / project condition | Axes and content need | Render / cost | Constraints and avoid | Sources |
|---|---|---|---|---|---:|
| [Responsive mode substitution](cards/responsive-mode-substitution.md) | Can the same priority survive by changing mode? Desktop cannot shrink intact. | Order, crop, density; explicit invariants | CSS/DOM/media; medium | Preserve all routes and controls; avoid when fluid reflow works | 1 |
| [Persistent orientation chrome](cards/persistent-orientation-chrome.md) | How will users know position and exit? Progression is nonstandard and bounded. | Cue, persistence, escape; scene map | semantic DOM over any scene; medium | Keyboard, touch, reduced motion; avoid ordinary pages | 2 |
| [Spatial tour with conventional closure](cards/spatial-tour-with-conventional-closure.md) | Should exploration lead to a scannable decision close? Few memorable stations exist. | Axis, stations, close; practical FAQ/pricing/action | DOM/SVG/hybrid; high | Linear fallback and direct close; avoid dense reference tasks | 1 |
| [Anchored editorial irregularity](cards/anchored-editorial-irregularity.md) | Which stable rule makes variation feel intentional? Authored media supports curation. | Scale, crop, alignment; meaningful portfolio content | CSS Grid/media; medium | DOM order and mobile crops; avoid repeated task controls | 2 |
| [Recurring proof rhythm](cards/recurring-proof-rhythm.md) | What evidence resolves each expressive claim? Verified proof is available. | Cadence, adjacency, evidence type; demos/results/constraints | DOM/media; medium | Contextualize claims; avoid when proof is unavailable | 3 |
| [Utility islands over immersion](cards/utility-islands-over-immersion.md) | Which interface responsibilities must survive active media? One scene dominates. | Edge, contrast, consolidation; identity/actions/status | DOM over video/canvas; high | Focus, safe areas, failure fallback; avoid dense apps | 2 |
| [Semantic system object](cards/semantic-system-object.md) | Does one geometry explain a real relationship? The product has a stable connected model. | Shape, labels, detail; equivalent textual decomposition | SVG/DOM/canvas; high | Named regions and list fallback; avoid arbitrary taxonomies | 1 |
| [Demonstration before decomposition](cards/demonstration-before-decomposition.md) | Should users see the unfamiliar loop before learning its vocabulary? A representative scenario exists. | Scenario, medium, taxonomy; honest workflow evidence | video/stills/live demo; medium | Captions, transcript, skip; avoid unreproducible spectacle | 1 |

## Vocabulary

Load [structure and composition](vocabulary/structure-composition.md), [typography and content](vocabulary/typography-content.md), [visual material and depth](vocabulary/visual-material-depth.md), or [interaction and state](vocabulary/interaction-state.md) only when that domain dominates. Load [motion](vocabulary/motion.md) only when motion is material.

## Size and sharding

Keep this root within 300–700 words. Seven required selection simulations routed accurately within this budget, so no shard is justified. If a later pilot cannot route validated cards accurately, shard by stable design job or domain and load this tiny root plus at most one relevant shard. Never expand the root into a design encyclopedia.
