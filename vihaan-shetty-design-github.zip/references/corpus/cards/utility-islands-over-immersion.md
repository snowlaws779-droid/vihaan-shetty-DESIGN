---
id: card-utility-islands-over-immersion
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-08, ref-09]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 776716b8e43780cf4d5a3ed11eb21362d18e9cac318db8465fb4f20b99e67e2a
---

# Utility islands over immersion

Place critical actions in independently legible utility islands around an immersive media field. Each island owns one job—identity, primary navigation, contact, status, sound, or progress—and maintains sufficient contrast regardless of the scene beneath it. The media supplies atmosphere; the islands preserve task completion. This differs from generic floating cards because placement follows persistent interface responsibility, not decoration.

Use this when a full-viewport video, canvas, or richly layered image is central to the proposition. Limit the number of islands and rank them. Identity and escape should remain stable; secondary status can yield on narrow screens. If an island changes state, name the state directly. Sound must begin off or by explicit consent.

Prerequisites: a simple action model, robust contrast treatment, safe-area rules, and a semantic layer independent of the rendered scene. Costs: z-index and collision management, breakpoint-specific placement, backdrop testing, and focus treatment. Failure conditions: islands cover focal content, controls resemble decoration, the scene failure removes navigation, or mobile stacking consumes most of the viewport.

Accessibility: use native controls, visible focus, unambiguous names, state announcements, and a bypass around the immersive region. Responsive: consolidate secondary islands into a complete menu while retaining primary action and escape. Performance: render islands in resilient DOM and load them before or independently from expensive media.

Anti-copy boundary: reuse the responsibility-based island system only. Do not copy source HUD frames, panel shapes, microcopy, atmospheric footage, sound treatment, palettes, or exact corner placements.

Decision profile: plausible families include fixed DOM controls, sticky toolbars, safe-area overlays and progressive enhancement over video or canvas. A conventional header and content column is the primary alternative and should win when immersion is secondary. Compatible with orientation and responsive substitution; conflicts with uncontrolled overlays. Variation axes: responsibility, edge, consolidation, contrast field and persistence. Appropriate for one dominant immersive stage; inappropriate for dense multi-task applications.
