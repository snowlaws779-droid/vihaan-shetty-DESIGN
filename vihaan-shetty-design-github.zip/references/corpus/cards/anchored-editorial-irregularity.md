---
id: card-anchored-editorial-irregularity
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-05, ref-07]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: de66066907d5ff9ab6e0e27762c5a5a0f04f2e9c44560de73eff4b98aadaf3e9
---

# Anchored editorial irregularity

Irregular scale, alignment, and cropping can signal curation when a quieter system supplies orientation. Use one or two stable anchors—section labels, a baseline, a repeated text measure, a persistent nav, or a predictable alternation—then vary media size and typographic placement around them. The anchor makes difference readable as intention; without it, the same variation becomes accidental noise.

This pattern suits portfolios, architecture, culture, and brand narratives where the work should not feel like interchangeable cards. First define the reading order in plain structure. Then decide which element remains stable while images, whitespace, or headline position vary. Let large type control pace only when the copy stays comprehensible and the mobile order is explicit. The purpose is not maximal difference on every section. It is a repeatable tension between one dependable rule and one changing axis.

Prerequisites: strong content hierarchy, meaningful media, a stable navigation route, and an editorial reason for variation. Costs: bespoke art direction, more responsive decisions, image-crop review, and longer visual QA. Failure conditions: every section invents a new grammar, labels become too quiet to perceive, reading order diverges from DOM order, or decorative line breaking damages comprehension.

Accessibility: maintain semantic headings and logical focus order independently of visual placement. Responsive: choose new crops and line breaks for narrow screens; do not preserve desktop emptiness at the cost of content. Performance: reserve dimensions for staggered media and avoid loading an entire portfolio at entry.

Anti-copy boundary: reuse the anchor-and-variation relationship only. Do not copy source typefaces, Spanish copy, black-and-white identity, project crops, loader treatment, or exact placements.

Decision profile: plausible families include CSS Grid, editorial flex layouts and art-directed media queries. A regular modular grid is the primary alternative and should win when comparison speed matters more than curation. Compatible with recurring proof and responsive substitution; conflicts with dense repeated controls. Variation axes: anchor, crop, scale, measure, cadence and alignment. Appropriate for authored narratives and portfolios; inappropriate for data tables, task queues and high-frequency workflows.
