---
id: card-recurring-proof-rhythm
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-06, ref-11, ref-12]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 9806f3bb88bbcbc7e48819fe1987fc3af65af46415ff1eab045b43810d7b81dd
---

# Recurring proof rhythm

Alternate expressive claims with concrete proof at a repeatable cadence. A large promise earns attention, but a demonstration, project, metric, testimonial, or bounded offer should answer the next likely doubt before the page returns to atmosphere. Repetition creates trust because each expressive rise has an evidentiary landing. It also creates pacing: users can skim the proof points even when they do not follow every transition.

Use this for unfamiliar products, premium services, or founder-led brands where emotion and credibility both matter. Choose proof that matches the claim: show workflow for capability, outcomes for value, constraints for reliability, and examples for range. Keep each proof block independently understandable. Avoid decorative metrics and client logos that do not substantiate the adjacent statement.

Prerequisites: real evidence, a clear sequence of user questions, and permission to present the evidence accurately. Costs: content gathering, legal review, media production, and maintenance as facts age. Failure conditions: proof is vague, repeated modules become monotonous, animation delays access, or metrics lack context. A demonstration is not proof of general reliability; a single result is not a universal promise.

Accessibility: captions, transcripts, alt text, and text equivalents must carry the same claim as visual proof. Responsive: preserve claim-to-proof adjacency even when sticky layouts collapse. Performance: defer rich demonstrations, provide posters, and keep essential claims readable before media loads.

Anti-copy boundary: reuse the claim-to-proof cadence only. Do not borrow source metrics, testimonials, product UI, headlines, client marks, visual identity, or animation timing.

Decision profile: plausible families include alternating DOM sections, sticky claim/proof handoffs, inline demos and case-study modules. A compact evidence summary is the primary alternative and should win for urgent or repeat-use tasks. Compatible with demonstration-first and editorial cards; conflicts with unsupported marketing claims. Variation axes: evidence type, cadence, density, adjacency and reveal. Appropriate when trust must accumulate; inappropriate when no verified proof exists.
