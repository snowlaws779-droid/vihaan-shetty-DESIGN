---
id: card-responsive-mode-substitution
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-01]
observation_window: 2026-09-09T18:42:00+04:00/2026-09-09T19:00:00+04:00
confidence: high
promotion_hash: d48ea984b65bca921e55451cff6e3cb0a64841d59f5c3264b38547c161a1d172
---

# Responsive mode substitution

When an expressive desktop system loses the space required for its hierarchy, substitute the coordinated interaction mode instead of shrinking every element. Change the navigation pattern, media crop or source, type layout and control density as one decision so the same priority survives at a different width.

Use this when a persistent rail, large spatial composition or media framing cannot remain legible and operable on a narrow viewport. First define what must remain invariant: task priority, route access, state clarity and essential evidence. Then design the smallest complete mobile mode that preserves those invariants.

Prerequisites: an explicit content hierarchy, representative viewport testing and separate asset/control decisions. Costs: more variants, asset weight and QA. Failure conditions: hidden destinations, a mobile mode with incomplete controls, cropped essential content, or source switching that causes loading regressions.

Accessibility: keep destinations, names and focus behavior equivalent. Responsive: test the actual rendered modes, not only breakpoint declarations. Performance: avoid downloading desktop and mobile media when only one is used.

Define invariants before variants: the primary claim, complete route access, control meaning and recovery path must survive every mode. Then choose which surface properties may change, such as crop, order, navigation container or motion. Remove the substitution if it creates duplicated content ownership, divergent capabilities or an untestable matrix; a fluid layout is preferable when it preserves the same priorities cleanly and reliably.

Anti-copy boundary: reuse the reasoning pattern only. Do not reproduce a source's navigation geometry, copy, imagery, color system or motion signature.

Decision profile: plausible families include CSS reflow, alternate DOM arrangements, art-directed media and progressive enhancement. A fluid layout is the primary alternative explanation and should win when it preserves all invariants. Compatible with orientation and proof cards; conflicts with any card that requires identical geometry across modes. Variation axes: order, crop, density, navigation container, motion and rendering class. Appropriate for a material mode change; inappropriate for minor breakpoint tuning.
