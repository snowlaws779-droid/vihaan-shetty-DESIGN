---
id: card-persistent-orientation-chrome
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-03, ref-04]
observation_window: 2026-09-09T19:06:00+04:00/2026-09-09T19:40:00+04:00
confidence: high
promotion_hash: 9a9ada458acc3fde464e63a626a28a6604c3ae16dac204c90926d4a47935c302
---

# Persistent orientation chrome

When content moves along an unfamiliar axis or through a spatial scene, keep a small set of orientation and escape controls stable. A persistent identity cue, progress signal and next-or-exit action reduce the cognitive cost of expressive progression because the user does not have to relearn where they are or how to leave.

Use this for short editorial, lateral or spatial journeys whose movement is intentionally nonstandard. Keep the chrome quieter than the content, but make it semantically named and keyboard reachable. On mobile, substitute or simplify the controls if the desktop arrangement no longer fits; do not merely hide them.

Prerequisites: bounded scene count, explicit progress model and a conventional fallback path. Costs: fixed-screen space, layering complexity and extra responsive states. Failure conditions: unnamed controls, occluded content, misleading progress, no skip path, or persistent chrome that competes with the story.

Accessibility: expose progress and controls independently of visual location and honor reduced motion. Responsive: re-evaluate which controls must persist at each mode. Performance: keep the stable chrome DOM-based where practical so it remains available if a heavy scene fails.

Before adopting it, answer three questions: can a user identify current position without motion, can they reach the next meaningful destination with keyboard and touch, and can they exit the expressive sequence immediately? Remove or simplify the pattern if the answers depend on animation, hidden gestures or a functioning canvas. Verify orientation after every scene transition, not only at entry.

Anti-copy boundary: reuse the orientation principle only. Do not reproduce source logos, control placements, wording, palettes, camera paths or compositions.

Decision profile: plausible families include fixed semantic DOM, sticky section navigation and accessible progress controls. A conventional document outline is the primary alternative and should win when progression is not genuinely unusual. Compatible with responsive substitution, spatial closure and utility islands; conflicts with uninterrupted full-bleed content that cannot reserve safe space. Variation axes: cue type, persistence, edge, density and escape model. Appropriate for bounded nonstandard progression; inappropriate for ordinary pages.
