---
id: card-demonstration-before-decomposition
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-11]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: high
promotion_hash: 77075edd6a2552e59fdc5857b940b59288a15efa2c69dac71b4c06206b3a8ee3
---

# Demonstration before decomposition

Show one representative workflow or outcome before presenting the capability taxonomy. The demonstration gives later labels a concrete referent; decomposition then helps users generalize beyond the example. The sequence should answer “what happens?” before “what are all the parts?” and then return to constraints, fit, or action.

Use this for new interaction paradigms, agentic tools, technical platforms, and products whose category language is still unstable. Pick a demonstration that reflects the core loop rather than an edge-case spectacle. Frame its start, intervention, and outcome. Follow it with a small capability vocabulary that maps directly back to observed moments. Provide a skip and a concise text summary for users who cannot or do not want to play media.

Prerequisites: an honest representative scenario, stable demo media, and a clear mapping from moments to capabilities. Costs: production, captions, updates as UI changes, and potential loading delay. Failure conditions: the demo is simulated without disclosure, hides setup or failure states, autoplays disruptive audio, or the subsequent taxonomy introduces unrelated claims.

Accessibility: include captions, transcript, controls, poster, and a structured textual walkthrough. Responsive: crop or recompose the demonstration while keeping key UI legible; provide still steps when video becomes unreadable. Performance: lazy-load below-the-fold media and reserve dimensions to avoid layout shifts.

Anti-copy boundary: reuse the demonstrate-then-name sequence only. Do not copy source product UI, icons, video framing, wording, monochrome styling, or capability order.

Decision profile: plausible families include captioned video, interactive walkthrough, annotated still sequence and live sandbox. A concise text example is the primary alternative and should win when media cost outweighs clarity. Compatible with recurring proof and semantic system objects; conflicts with unreproducible spectacle. Variation axes: scenario, medium, intervention points, taxonomy depth and skip path. Appropriate for unfamiliar workflows; inappropriate when the task is already well understood.
