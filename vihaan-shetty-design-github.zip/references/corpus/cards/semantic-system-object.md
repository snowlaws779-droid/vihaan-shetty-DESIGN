---
id: card-semantic-system-object
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-10]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: medium
promotion_hash: 44d317b8518dd78abca1729ad845c2e993fdf9df823ebc22e295056982f4638a
---

# Semantic system object

Represent a system with one coherent visual object, then provide a semantic decomposition beside or beneath it. Concentric rings, a map, a stack, a pipeline, or another domain-appropriate form can communicate relationships faster than a list. The object earns its place only if its geometry encodes a real distinction—sequence, containment, exchange, hierarchy, or state—and the equivalent meaning remains available without manipulation.

Use this for platforms whose value comes from connected parts rather than isolated features. Name the relationship before choosing the shape. Give the object a stable overview state, bounded interactions, and a textual inventory that follows the same model. If interaction reveals details, make each reveal reachable by keyboard and expose selected state programmatically.

Prerequisites: a defensible information model, few enough parts to remain legible, and an equivalent linear explanation. Costs: custom illustration or rendering, interaction semantics, responsive redesign, and maintenance when the product model changes. Failure conditions: geometry is arbitrary, labels require constant rotation, the object becomes a mystery-meat menu, or motion is the only explanation.

Accessibility: provide a heading, summary, ordered or grouped text, and named controls for every selectable region. Responsive: simplify labels, change representation, or move to a list rather than miniaturizing the desktop object. Performance: prefer SVG or DOM when sufficient and keep the semantic explanation independent of canvas.

Anti-copy boundary: reuse the one-object-plus-decomposition logic only. Do not copy source concentric rings, labels, monochrome identity, live status, brush marks, motion, or layout.

Decision profile: plausible families include semantic SVG, structured DOM diagrams, static illustration and progressively enhanced canvas. A grouped feature list is the primary alternative and should win when relationships are weak. Compatible with demonstration-first and responsive substitution; conflicts with arbitrary geometry or unlabeled hotspots. Variation axes: relationship type, shape, interaction depth, label strategy and fallback. Appropriate for a stable connected model; inappropriate for rapidly changing taxonomies.
