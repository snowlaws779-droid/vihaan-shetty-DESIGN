---
id: card-spatial-tour-with-conventional-closure
corpus_version: 0.5-phase5
status: promoted
stable_source_ids: [ref-02]
observation_window: 2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00
confidence: medium
promotion_hash: 304b0a57db7100b3225deb5d9d33414c74ad3cecc3f3df891586c60b72c8d4f0
---

# Spatial tour with conventional closure

When a product benefits from spatial exploration, keep the expressive tour bounded and close it with conventional decision content. The unusual progression earns attention and demonstrates character; familiar pricing, FAQs, contact, or comparison restores scanning speed when the user is ready to decide. The relationship matters more than either surface alone: exploration builds a mental model, while the conventional close prevents the interaction model from becoming a tax on every task.

Use this when a small set of capabilities can be represented as memorable stations and the audience has time to explore. Establish a stable coordinate, progress, or section cue before movement begins. Make every station reachable by more than a hidden gesture, preserve a linear semantic reading order, and let users jump directly to the practical close. On narrow screens, replace the spatial mechanism if it no longer fits; preserve the station sequence and route access.

Prerequisites: a short scene inventory, clear orientation, semantic content outside the rendering surface, and a conventional exit. Costs: interaction teaching, responsive variants, asset loading, and additional accessibility QA. Failure conditions: the tour hides essential facts, traps keyboard users, implies false geography, or forces motion on users who prefer less.

Accessibility: expose station names, current position, skip controls, focus order, and a reduced-motion linear path. Responsive: allow a vertical or paged substitute rather than compressing a desktop coordinate field. Performance: keep decision content independent of the richest rendering layer so it survives failure.

Anti-copy boundary: reuse the exploration-to-closure relationship only. Do not reuse source coordinates, grid appearance, illustrations, feature names, colors, copy, or scene choreography.

Decision profile: plausible families include native paged sections, transformed DOM, SVG maps and hybrid canvas with DOM stations. An ordinary feature sequence is the primary alternative and should win when exploration adds no understanding. Compatible with orientation chrome and responsive substitution; conflicts with dense reference tasks. Variation axes: station count, axis, progress cue, close type and fallback. Appropriate for short exploratory stories; inappropriate when facts must be scanned immediately.
