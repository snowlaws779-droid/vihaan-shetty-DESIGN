# Runtime Corpus Provenance

Corpus version: `0.5-phase5`

This runtime uses two-level provenance.

## Level 1 — runtime provenance summary

Each card contains stable source IDs, corpus version, observation window, confidence and a SHA-256 promotion hash. The hash is calculated over the UTF-8 card with its `promotion_hash` value normalized to 64 zeroes. This summary supports routing and integrity checks without exposing development-only paths.

- `card-anchored-editorial-irregularity`: sources `ref-05, ref-07`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `de66066907d5ff9ab6e0e27762c5a5a0f04f2e9c44560de73eff4b98aadaf3e9`.
- `card-demonstration-before-decomposition`: sources `ref-11`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `77075edd6a2552e59fdc5857b940b59288a15efa2c69dac71b4c06206b3a8ee3`.
- `card-persistent-orientation-chrome`: sources `ref-03, ref-04`; observation window `2026-09-09T19:06:00+04:00/2026-09-09T19:40:00+04:00`; confidence `high`; promotion hash `9a9ada458acc3fde464e63a626a28a6604c3ae16dac204c90926d4a47935c302`.
- `card-recurring-proof-rhythm`: sources `ref-06, ref-11, ref-12`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `9806f3bb88bbcbc7e48819fe1987fc3af65af46415ff1eab045b43810d7b81dd`.
- `card-responsive-mode-substitution`: sources `ref-01`; observation window `2026-09-09T18:42:00+04:00/2026-09-09T19:00:00+04:00`; confidence `high`; promotion hash `d48ea984b65bca921e55451cff6e3cb0a64841d59f5c3264b38547c161a1d172`.
- `card-semantic-system-object`: sources `ref-10`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `medium`; promotion hash `44d317b8518dd78abca1729ad845c2e993fdf9df823ebc22e295056982f4638a`.
- `card-spatial-tour-with-conventional-closure`: sources `ref-02`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `medium`; promotion hash `304b0a57db7100b3225deb5d9d33414c74ad3cecc3f3df891586c60b72c8d4f0`.
- `card-utility-islands-over-immersion`: sources `ref-08, ref-09`; observation window `2026-09-10T16:45:00+04:00/2026-09-10T18:15:00+04:00`; confidence `high`; promotion hash `776716b8e43780cf4d5a3ed11eb21362d18e9cac318db8465fb4f20b99e67e2a`.

The distributed runtime contains no absolute or relative filesystem links to an undistributed development harness.

## Level 2 — development-harness evidence trace

The archived harness retains screenshots, interaction sequences, measurements, findings, claim audits, limitations, promotion decisions and resolvable raw-evidence pointers. Stable source and evidence IDs connect the two levels. Full evidence paths remain inside that archive and are intentionally absent from runtime context.
