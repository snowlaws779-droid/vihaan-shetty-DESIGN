# Structure and composition vocabulary

Use this module after the corpus index when the design problem is primarily page sequence, spatial organization, or hierarchy. It routes among causal cards; it does not add source evidence.

## Start with the user's next question

Choose the next section by the doubt it must resolve. If an expressive claim needs credibility, route to **recurring proof rhythm**. If an unfamiliar interaction needs a safe landing, route to **spatial tour with conventional closure**. If the material itself should feel curated rather than catalogued, consider **anchored editorial irregularity**. The question-to-section relationship is the structure; visual styling follows it.

## Stable rule versus changing axis

Art-directed composition usually needs one stable rule. That rule may be a grid line, reading measure, section label, navigation position, or repeated claim-to-proof cadence. Vary one dominant axis around it: scale, crop, alignment, density, or scene depth. When three or more axes change together, add a stronger anchor or simplify. Load **persistent orientation chrome** when the changing axis is movement itself.

## Sequence patterns

- Promise → demonstration → decomposition → fit/action: use for an unfamiliar product. Load **demonstration before decomposition**, optionally followed by **recurring proof rhythm**.
- Atmosphere → project/result → atmosphere → project/result: use for premium or founder-led services. Load **recurring proof rhythm**.
- Overview object → selected part → textual inventory: use when the offer is a connected system. Load **semantic system object**.
- Expressive stations → practical comparison or FAQ: use for bounded exploration. Load **spatial tour with conventional closure**.

## Composition checks

The visual order and DOM order should tell the same story. Every oversized field needs a reason: emphasis, pause, comparison, or immersion. Empty space must preserve hierarchy rather than postpone information. Sticky or fixed layers must release before they collide with the next responsibility. On mobile, recompose; do not preserve desktop irregularity by forcing tiny type, horizontal overflow, or excessive blank space.

## Combination rule

Ordinarily load no more than three cards. One card should own sequence, one may own orientation or responsive substitution, and one may own proof. If two cards dictate the same section behavior, keep the more specific one. Document rejected cards in the project selection rather than blending every idea.

## Failure boundary

Reject expressive composition when it obscures task priority, makes the route dependent on canvas, breaks semantic order, or requires more content than the project has. The corpus supplies options, never permission to weaken product truth.

## Practical composition pass

Before drawing sections, write the task spine as verbs: understand, compare, inspect, decide, recover. Attach one content responsibility to each verb. Then sketch the least expressive sequence that completes it. Only after that baseline is coherent should a card alter pacing or space. This keeps novelty attached to a real transition instead of spreading it evenly across the page.

Test the sequence at three levels. At page level, confirm that the opening promise and final action agree. At section level, confirm that every scene resolves one question and creates at most one new one. At viewport level, confirm that the dominant element, supporting explanation, and next action can coexist without ambiguous priority. A sticky region should announce why it persists and when it releases.

For existing products, preservation comes first. Map current routes, forms, states, and repeated components before moving content. A new composition may change visual grouping without changing task order, or may change sequence only when the user authorizes that behavioral impact. Record which choice was made.

Use content stress tests before approval: a short title, a long title, missing media, an error state, localization expansion, and a narrow viewport. If the composition works only with ideal copy and perfect images, it is a poster rather than a durable interface. The final direction should name both the stable structural rule and the deliberately varied axis so implementation and critique have a shared standard.
