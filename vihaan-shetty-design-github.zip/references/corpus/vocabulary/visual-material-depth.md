# Visual material and depth vocabulary

Use this module when imagery, rendered surfaces, texture, or spatial layering is material to the direction. It helps decide how much immersion the product can support and which stable interface layer must remain above it.

## Choose the medium by responsibility

Use ordinary images when the job is evidence, comparison, or editorial pacing. Use video when temporal change is itself the evidence or atmosphere. Use SVG when a system diagram needs scalable labels and semantic support. Use Canvas or WebGL only when continuous spatial transformation or rendering is essential to the proposition. A technically expensive medium is not automatically more expressive.

**Semantic system object** helps when one visual form must explain connected parts. The geometry must encode a real relationship, and a textual decomposition must carry equivalent meaning. If an SVG can do the job, prefer it over canvas because focus, labels, responsiveness, and failure handling are easier.

**Utility islands over immersion** applies when media owns most of the viewport. Keep identity, primary action, navigation, status, and escape in resilient, high-contrast DOM layers. Each island should have one responsibility and remain legible against the worst frame, not only the hero poster. Avoid scattering decorative cards around a scene.

## Depth ladder

Build depth in a deliberate order: base color or image, content field, local overlays, persistent utility, temporary modal. Document which layer can occlude another. Sticky chapters need release points; fixed controls need safe-area and collision rules. Blur, grain, halftone, glow, and blend modes can support atmosphere, but they should not reduce text contrast or imply interaction where none exists.

## Evidence and atmosphere

Atmospheric media should not carry factual content alone. Pair it with visible text or a later proof block. Use **recurring proof rhythm** when the experience needs to alternate feeling and evidence. Keep posters, captions, alt text, and outcome context available before rich media completes.

## Responsive transformation

Reframe rather than shrink. Change crop, replace ambient video with a still, simplify a system object, consolidate utility islands, or move from spatial depth to a vertical sequence. Preserve the proposition and actions, not every decorative layer. Test portrait devices where background focal points and persistent controls compete most severely.

## Performance and failure

Reserve dimensions, compress and size assets, defer offscreen media, stop animation in hidden tabs, and provide a meaningful no-canvas state. Set a budget before adopting multiple video or WebGL layers. Verify the experience under slow loading and media failure. Reject depth that removes navigation when a renderer fails or consumes the budget without improving comprehension, trust, orientation, or delight.

## Material direction contract

For each visual medium, record its content role, focal subject, crop behavior, loading state, fallback, rights or provenance, and removal condition. This prevents the asset list from becoming a moodboard with no implementation responsibility. A hero video may establish place; project images may prove range; a diagram may explain structure. If two media layers have the same role, remove or combine one.

Depth should clarify hierarchy through occlusion, scale, focus, or motion, but never conceal the task. Decide where text sits when the background reaches its lightest, darkest, and busiest frames. Use protective fields, scrims, or dedicated surfaces based on those worst cases. Validate forced-colors and reduced-transparency contexts where relevant rather than assuming a blend mode will survive.

Treat loading as part of the composition. A poster, reserved aspect ratio, skeleton, or quiet color field should preserve the intended hierarchy before rich media arrives. Loader branding may create continuity, but it cannot indefinitely block navigation or content. Timeouts and retry states need ordinary language.

For existing projects, inventory current asset URLs, intrinsic dimensions, CMS crops, and caching behavior before replacement. Preserve SEO-relevant alt text and structured content unless scope explicitly changes them. For greenfield work, use placeholders only as clearly labeled implementation scaffolding and never present them as finished product evidence.

Approve the material system after testing normal, slow, failed, paused, and reduced-motion states. If the static fallback feels like a broken version of the concept, the concept is too dependent on the rendering layer and should be simplified.
