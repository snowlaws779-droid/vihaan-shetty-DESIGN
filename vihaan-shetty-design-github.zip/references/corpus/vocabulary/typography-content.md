# Typography and content vocabulary

Use this module when the central decision concerns reading pace, claim hierarchy, editorial voice, or the relationship between expressive type and evidence.

## Typography has a job

Name the job before selecting a type treatment: announce, orient, explain, compare, prove, or invite action. Display scale is justified when it creates a meaningful pause or establishes a proposition. Dense supporting type is justified when it increases decision value. If a line break, letter animation, or unusual alignment does neither, remove it.

**Anchored editorial irregularity** is relevant when typography and imagery should feel composed rather than templated. Keep semantic headings intact, select a stable measure or alignment, then vary scale or placement. Do not copy a source typeface or headline shape. On narrow screens, write new line breaks and preserve the intended reading order.

## Claims need adjacent proof

Use **recurring proof rhythm** when bold language risks outrunning evidence. Pair capability claims with demonstrations, value claims with contextualized outcomes, reliability claims with constraints or process, and range claims with representative work. A logo wall is trust context, not proof of a specific outcome. A metric needs scope and provenance.

For unfamiliar products, **demonstration before decomposition** can reduce jargon. Begin with a short statement of the user's goal, show a representative loop, and only then name the component capabilities. The labels should map back to the example; otherwise the decomposition is a second unrelated pitch.

## Pace controls

Pace comes from sentence length, line measure, contrast, whitespace, repetition, and reveal order—not only animation. Use large statements sparingly so each retains signal. Follow an emotional line with a concrete sentence that clarifies audience, action, or evidence. Let utility copy remain conventional even inside an expressive frame. Navigation, consent, errors, pricing, and form instructions should not become riddles.

## Accessible expression

Never split text into letters or duplicate visual layers without verifying the accessibility tree. Preserve a clean semantic string, language metadata, zoom behavior, and contrast. If a moving headline is material, provide a static reduced-motion state that shows the complete thought. Avoid justified or excessively narrow text that creates rivers or difficult tracking.

## Selection questions

Ask: What must the user remember? What must they understand? What must they trust? What action follows? Choose one expressive typographic device for the memory job, a quiet system for understanding, and explicit evidence for trust. If the same device tries to do all three, it will usually become noisy.

Reject any treatment that depends on copied wording, damages comprehension, or produces a semantic tree more chaotic than the visual result warrants.

## Build a functional type system

Define roles before sizes: display proposition, section claim, reading text, evidence label, metadata, control, and status. Assign each role a consistent family, weight range, measure, and contrast. A project rarely needs a separate visual treatment for every section. Distinction can come from scale and spacing while the role system stays stable.

Set readable defaults first. Body copy should tolerate browser zoom and localization. Controls need adequate size and clear verbs. Metadata may be quieter, but it must remain legible where it carries dates, prices, progress, or qualifications. Test mixed case, numerals, punctuation, and long unbroken strings; a typeface that looks strong in one hero word may fail in product content.

Content hierarchy should survive without layout. Read headings and paragraphs in DOM order. If the narrative becomes incoherent, repair the information model rather than relying on placement or animation. Avoid duplicated live text used solely for visual effects. When duplicates are unavoidable, expose one canonical semantic string and hide purely visual copies correctly.

For major direction work, record a content contract: primary proposition, evidence types, required caveats, calls to action, and prohibited invented claims. Typography should amplify this contract. It must not smuggle in unsupported confidence through oversized numbers, fabricated social proof, or vague superlatives.

During critique, remove one type treatment and see whether hierarchy improves. If it does, the removed treatment was competing rather than contributing. Approve the system only after desktop and mobile line breaks, zoom, focus indicators, loading substitutions, and error messages have all been seen in the rendered interface.
