# Motion vocabulary

Load this module only when motion is materially required by the project. Motion must serve orientation, hierarchy, feedback, continuity, narrative, atmosphere, or bounded delight. If its purpose cannot be named, use a static treatment.

## Select by purpose

For orientation, use **persistent orientation chrome** around nonstandard progression. The chrome itself should move minimally; its stability is the point. For hierarchy, use restrained chapter handoffs or demonstration sequencing. For narrative, **spatial tour with conventional closure** can stage a short journey, but practical content must remain directly reachable. For atmosphere, **utility islands over immersion** keeps active media from erasing usability. For explanation, **demonstration before decomposition** uses temporal evidence before abstract labels.

## Behavior model before easing

Specify trigger, input, state progression, mapping, timing status, rendering class, lifecycle, fallback, and reduced-motion result. “Smooth scroll” or “cinematic” is not a behavior model. Decide whether motion is time-driven, input-driven, or state-driven. Input-driven motion needs clamping, reversal, and device normalization. State-driven motion needs a clear start and end state. Time-driven ambient motion needs pause rules.

## Timing vocabulary

Use short transitions for feedback, medium transitions for spatial continuity, and longer sequences only for intentional narrative. Exact duration should be tuned in the real interface. Easing should reflect the physical or attentional relationship: quick deceleration for direct manipulation, symmetric ease for neutral continuity, and linear mapping for progress that must track input. Avoid chaining delays that make content wait for decoration.

## Reduced motion

Reduced motion is a designed state, not animation set to zero everywhere. Preserve hierarchy and causality: replace parallax with static depth, spatial travel with cuts or fades, letter sequencing with complete text, and auto-rotating objects with a stable overview plus controls. Never remove content, progress, or feedback. If the environment cannot demonstrate the reduced-motion behavior, record it as blocked and do not claim completion.

## Performance lifecycle

Prefer transform and opacity for DOM motion, but still measure. Pause video, canvas, and requestAnimationFrame work when offscreen or hidden. Respect device capability and data-saving contexts. Use posters and deterministic first frames. Avoid stacking multiple continuously animated layers beneath blur or blend modes without profiling.

## Verification

Test first load, interruption, reversal, resize, orientation change, keyboard operation, touch, background-tab return, media failure, and reduced motion. Motion is accepted only when it improves the named purpose without weakening comprehension, input access, or performance. Source choreography, timing signatures, particles, camera paths, and branded transitions remain outside the transfer boundary.

## Motion unit contract

Treat each substantial effect as a unit with an owner and a removal threshold. Record purpose, trigger, source input, start and end states, progress mapping, duration status, easing status, rendering layer, lifecycle, accessibility behavior, and fallback. Separate directly observed behavior from inferred implementation. A public bundle name is a signal, not proof that the effect uses it.

Coordinate units at the page level. One dominant narrative motion can coexist with small feedback transitions, but several competing scroll mappings will fracture attention. Define which unit owns the scroll signal, which elements are passive followers, and which controls remain stable. Avoid nested smooth-scrolling systems or independent animation loops unless measurement justifies them.

Interruption is a design state. User input should be able to reverse or complete direct manipulation without waiting for a queued timeline. Route changes and modal opens should cancel irrelevant work. Resizing must recompute geometry without jumping past content. When hydration or media loading finishes late, it should not replay an entrance that moves content under the user's pointer.

Set budgets in terms the project can verify: number and size of media assets, concurrent videos, long tasks, layout shifts, frame stability, battery-sensitive loops, and fallback behavior. Match the sophistication of the technique to the available QA. A modest DOM transition with complete input and reduced-motion coverage is preferable to an untestable rendered spectacle.

During critique, temporarily remove each motion unit. If hierarchy, orientation, feedback, continuity, narrative, atmosphere, or delight does not materially worsen, remove the unit permanently. This deletion test is the strongest defense against motion that exists only to resemble a reference.
