# Interaction and state vocabulary

Use this module when the key design question is navigation, state feedback, spatial progression, or the relationship between immersive behavior and ordinary controls.

## Make the interaction model explicit

A user should be able to answer: where am I, what can I do, what changed, and how do I leave? For conventional pages, native scroll and links usually answer these questions. For lateral, virtual, or scene-based experiences, load **persistent orientation chrome** and define current position, progress, next action, skip, and exit. Directory or visual placement alone is not a control model; semantics and behavior must agree.

**Spatial tour with conventional closure** is useful when exploration is part of understanding but purchasing or evaluation still needs fast scanning. Keep the tour bounded, expose stations, and provide direct access to pricing, FAQ, contact, or comparison. Do not make practical content depend on completing the tour.

**Utility islands over immersion** helps distribute stable responsibilities around a full-viewport scene. Identity, navigation, sound, contact, and status should each have clear state and contrast. Consolidate secondary responsibilities on small screens without removing routes. Sound begins off and changes only through an explicit named control.

## State contract

For every control, specify idle, hover where applicable, focus-visible, active/pressed, loading, success, error, disabled, and reduced-motion behavior. Use visible text or standard semantics for state; do not rely on color, position, or animation alone. Preserve focus when menus open or close and return it predictably. Escape should dismiss temporary layers.

## Input equivalence

Wheel, pointer, touch, keyboard, and assistive technology do not produce identical events. Define the user intent—advance, select, inspect, dismiss—then support it across relevant inputs. A swipe-only scene needs buttons or links. A hover reveal needs focus and tap behavior. Scroll-jacking must never prevent reversal, browser shortcuts, or access to content.

## Responsive behavior

Load **responsive mode substitution** when the interaction grammar itself must change. A desktop spatial rail can become a mobile list; a field of utility islands can become a header plus complete menu; an animated diagram can become ordered steps. Test that every route and action survives the substitution.

## Failure boundary

Reject a novel interaction if users must guess the gesture, if the semantic order differs from the apparent order, if a renderer failure removes essential actions, or if reduced motion means missing content. The expressive layer should enhance a complete interaction model, not serve as its only implementation.

## Map state before polish

Create a state table for each material component. Include entry condition, available actions, resulting state, visible feedback, announced feedback, focus destination, persistence, escape, and failure recovery. This is especially important for menus, dialogs, filters, media controls, carousels, forms, and spatial scenes. A beautiful transition cannot compensate for an undefined state edge.

Use native platform behavior where it already expresses the intent. Links navigate, buttons cause actions, form controls expose values, and headings organize content. Custom cursor treatments, drag regions, and rendered hotspots are optional layers; they do not replace standard semantics. When a visual object is selectable, expose its selected state and equivalent text control.

Loading deserves explicit interaction policy. Prevent duplicate submissions without trapping the user, retain entered data through recoverable failures, and distinguish background loading from a blocked task. Optimistic feedback needs a rollback state. Animation may bridge state changes, but the end state must be immediately knowable when motion is absent.

Verify interruption: open a menu, resize; begin a transition, press Escape; scroll a virtual scene backward; background and restore the tab; rotate a touch device; trigger validation with keyboard only. Confirm that focus is neither lost nor moved behind an overlay. Test browser back and deep links where state affects navigation.

For small fixes, do not invent a new interaction system. Repair the bounded state while preserving surrounding behavior. For substantial existing-project work, load the behavior-preservation schema and record which routes, tasks, data and keyboard behaviors cannot regress before changing visual state.
