# Frontend and Regression Safeguards

Load for substantial implementation, especially existing-product work.

- Respect project instructions, framework, package manager, routing, styling, state ownership, tests, and component conventions.
- Model semantic structure and behavior before visual wrappers.
- Preserve deep links, browser navigation, titles, focus restoration, forms, validation, pending/duplicate prevention, success/failure recovery, authentication/authorization boundaries, data contracts, and required analytics.
- Keep authoritative or sensitive work on the correct server/client side; do not move trust to the browser for design convenience.
- Cover reachable loading, empty, success, warning, error, disabled, selected, active, hover, and focus states.
- Define tokens for stable repeated decisions. Do not flatten a deliberate one-off composition into a generic variant, or duplicate system tokens without reason.
- Structure advanced animation so setup, input mapping, interruption, visibility, resize, and cleanup remain reviewable.
- Check build/type/test plus browser console, hydration/runtime errors, requests, and assets.
- Record asset source and licensing. Review privacy effects of analytics, embeds, remote fonts/media, trackers, CDNs, and third-party libraries.
- Prefer progressive enhancement and graceful degradation for unavailable JavaScript/APIs, failed heavy assets, reduced motion, low power, and constrained networks when the product permits.

For every new dependency record the exact problem, why current capability is insufficient, bundle/runtime/maintenance/privacy cost, accessibility/browser risk, fallback, success measure, and removal threshold. Remove it if it duplicates current capability, solves a trivial isolated effect, breaks degradation, exceeds budget, or provides no measured improvement.

Use the behavior-preservation schema for substantial existing-project changes and verify affected invariants after implementation.
