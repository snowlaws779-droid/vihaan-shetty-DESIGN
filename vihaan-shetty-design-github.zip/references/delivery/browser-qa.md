# Browser QA

Load before claiming completion of substantial visual work.

## Evidence loop

`RUN → OPEN → INSPECT → INTERACT → RESIZE → CHECK STATES → CHECK RUNTIME → CRITIQUE → FIX → REGRESS`

Freeze representative sizes from project requirements. If none exist, use desktop `1440×900`, tablet `1024×768`, and mobile `390×844`; add a narrow stress width or real device when material.

Record routes/flows, browser/device/input, viewport, states, screenshots, recordings for material motion, keyboard/focus, touch/coarse-pointer alternative, reduced motion, zoom/reflow and content stress where relevant, console/hydration errors, failed requests, broken assets, loading/layout shift, budgeted performance, defects, fixes, regression checks, and limitations using `../schemas/qa-evidence.md`.

One modern engine is enough for routine iteration only when no support matrix, advanced/high-risk browser feature, or browser-specific symptom requires more. Use a secondary engine when declared support or advanced CSS/SVG/font/scroll/WebGL/media/input behavior creates risk. Use a real device when touch gesture, soft keyboard, mobile viewport chrome, sensor/media policy, mobile GPU, or low-power performance is central. Otherwise record the limitation.

Severity:

- S0: primary task, data/security, key viewport, or critical accessibility blocker.
- S1: serious task, hierarchy, interaction, responsive, accessibility, runtime, or performance defect.
- S2: visible issue materially reducing quality.
- S3: low-impact refinement.

No unresolved S0/S1 may remain. Fix high-impact S2. Stop when the evidence record is complete and another pass finds no new S0/S1 or high-value S2.

If browser inspection did not occur, use `not-visual-verified`. Compilation, screenshots supplied by someone else, or static review do not prove live behavior.
