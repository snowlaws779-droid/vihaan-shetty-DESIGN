# Responsive, Accessibility, and Performance

## Responsive composition

For every major section define invariant purpose; hierarchy at each composition state; grid, order, type measure, imagery crop, navigation/control, density, whitespace, and interaction transformation; pointer-to-touch alternative; motion reduction; and fallback. Add breakpoints when content or interaction fails, not because a framework supplies one. Inspect rendered desktop, tablet, mobile, and a stress width where material.

## Accessibility

Use the project’s applicable standard, normally an AA-level baseline unless stricter. Protect semantic landmarks/headings, labels, names/states, reading order, keyboard operation, visible focus, contrast/non-color cues, target sizing, zoom/reflow, dynamic announcements, dialog/menu/route focus management, media alternatives, and error recovery. Substantial motion needs reduced-motion behavior. Hover/pointer-only information needs touch and keyboard access.

Accessibility changes the design from the beginning; it is not a finishing patch. Replace a distinctive choice if it depends on exclusion.

## Performance

Set project-specific budgets before high-cost creative work. Track media/model/texture and font strategy, JavaScript/hydration, main-thread work, frame stability, memory/GPU, layout stability, interaction response, and expected low-end/mobile behavior.

For every expensive feature record:

`purpose → expected value → cost → measurement → fallback → removal threshold`

Size and lazy-load noncritical media, preserve stable layout, batch DOM reads/writes, pause hidden work, and clean up resources. Measure instead of assuming compositing or frame quality. If the effect harms the primary task on an expected device, simplify or remove it.
