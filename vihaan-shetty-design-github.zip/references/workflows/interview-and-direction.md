# Interview and Direction

Load this only for substantial greenfield work or a major redesign with unresolved creative decisions.

## Question gate

Ask zero questions for small fixes, fully specified work, or safe “choose for me.” Otherwise rank candidate uncertainties from 0–3 on design impact, genuine uncertainty, downstream breadth, and risk of being wrong; subtract inferability from existing evidence and user effort. Discard a question when the repository, rendered product, brief, content, or conversation already answers it, or when plausible answers would not change the direction contract.

Ask two to four high-information questions. A single blocking question is acceptable when everything else is specified. Stop before four when remaining uncertainty is low; reopen only for a newly discovered consequential conflict.

Questions should be project-specific comparisons with clear consequences. They may blend answers and include “use your judgment.” Avoid vague style labels or choosing technologies as proxies for experiences.

Examples to adapt, never repeat mechanically:

- For an urgent information page: immediate action first or explanation first; institutional or warmer clinical voice; mandatory always-visible content.
- For a repeat-use dashboard: fastest repeated decision; simultaneous density or progressive detail; permitted navigation change distance.
- For an editorial property experience: imagery, material detail, or place story as lead; quiet or selective cinematic pacing; whether supplied assets support full-viewport use.
- For education: independent practice, guided instruction, or assigned work; calm or playful feedback; student reading level.

## Answer conversion

Do not store only option letters. Translate each answer into affected decisions and constraints. For example, “immediate action first” changes information order, first-viewport hierarchy, CTA priority, and motion restraint. Resolve conflicts using project truth, then platform foundations, then corpus knowledge.

## Choose-for-me

Infer purpose, audience, task criticality, trust, content readiness, brand maturity, frequency, expected devices, and accessibility/performance ceilings. Generate two or three internal organizing ideas that differ in content/composition logic, select the strongest, state a concise thesis and material assumptions, then proceed. Do not ask for approval of routine design choices.

## Required artifact

For major work create a direction contract using `../schemas/direction-contract.md`. If corpus intelligence influences it, also create project selection and source ledger records. Version the contract only when a consequential discovery changes the direction.
