# Existing Project Workflow

Inspect before questioning or redesigning.

## Two truths

Repository truth covers instructions, routes, components, tokens, fonts, assets, dependencies, state ownership, forms, auth boundaries, tests, build commands, and conventions. Rendered truth covers actual hierarchy, spacing, content, navigation, interaction, motion, responsive transformation, loading/error states, console failures, and brand impression.

## Sequence

1. Read project instructions and map the relevant repository surface.
2. Run the current interface when possible and inspect affected flows at representative viewports.
3. Record brand equities, behavior invariants, technical boundaries, and visible defects.
4. Classify material elements as `preserve`, `improve`, `replace`, or `unresolved`, with evidence and risk.
5. Infer permitted change distance from the request. Ask only if ambiguity would materially change the outcome.
6. For substantial changes, load `../schemas/behavior-preservation.md` before editing.
7. Establish direction without erasing recognisable product concepts or breaking the task model.
8. Implement in risk order and verify affected invariants after each material slice.
9. Run browser QA, senior critique, regression checks, and repository checks.

“Replace” requires authorization and a stronger reason than personal preference. Visual improvement does not authorize changing routes, product language, data behavior, authentication, permissions, analytics contracts, or public APIs.

If the browser is unavailable, make the strongest static and test-based assessment possible, explicitly record the gap, and do not claim rendered inspection.
