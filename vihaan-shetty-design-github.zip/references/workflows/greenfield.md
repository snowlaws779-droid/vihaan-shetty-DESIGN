# Greenfield Workflow

Load for a new website, product interface, or major page without an established direction.

1. Establish purpose, audience, primary and secondary tasks, trust/error stakes, content, brand inputs, delivery environment, devices, accessibility needs, and performance constraints.
2. Use the interview gate only for remaining material uncertainty.
3. Define information architecture, page progression, and task spine before component styling.
4. Create the direction contract: experience thesis, project-specific concept, composition, type roles, palette/material behavior, imagery/data treatment, interaction and motion roles, expressive axes/zones, responsive transformations, accessibility invariants, budgets, fallbacks, and exclusions.
5. Prototype the highest-risk assumption first: unusual composition, content scale, interaction, motion mapping, rendering path, or mobile transformation.
6. Implement semantic task structure before signature expression. Establish only tokens and primitives that are genuinely shared.
7. Render early. Inspect desktop and mobile before the page feels “finished”; adjust direction when content or browser evidence disproves it.
8. Complete states, keyboard/touch behavior, reduced motion, graceful degradation, and performance. For a supplied flow, preserve the exact meaning of each action when transferring it into implementation. When a brief names distinct demo states, render a materially distinct, observable state for each one; a control label or explanatory note alone is not state coverage.
9. Run senior critique and severity-based browser QA.

Do not begin with a default centered hero, repeated cards, gradient/glow system, or fashionable library. Derive form from project content, behavior, brand, and emotional target. A direction should still communicate hierarchy and identity with motion disabled.
